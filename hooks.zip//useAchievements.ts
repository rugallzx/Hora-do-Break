import { useMemo } from 'react';

interface UserData {
  dailyScreenTime: number;
  coins: number;
  level: number;
  xp: number;
  completedMissions: string[];
  weeklyData: Array<{
    date: string;
    screenTime: number;
    missionsCompleted: number;
  }>;
  streakData?: {
    currentStreak: number;
    longestStreak: number;
    lastBreakDate: string;
  };
  achievements?: string[];
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  category: 'streak' | 'missions' | 'level' | 'time' | 'coins';
  requirement: number;
  unlocked: boolean;
  progress: number;
  maxProgress: number;
  reward: {
    coins: number;
    xp: number;
  };
}

export function useAchievements(userData: UserData) {
  const achievements = useMemo((): Achievement[] => {
    const userAchievements = userData.achievements || [];
    const currentStreak = userData.streakData?.currentStreak || 0;
    const longestStreak = userData.streakData?.longestStreak || 0;
    const totalMissions = userData.completedMissions.length;
    const weeklyMissions = userData.weeklyData
      .filter(d => {
        const date = new Date(d.date);
        const weekAgo = new Date();
        weekAgo.setDate(weekAgo.getDate() - 7);
        return date >= weekAgo;
      })
      .reduce((sum, d) => sum + d.missionsCompleted, 0);

    return [
      // Streak Achievements
      {
        id: 'streak_3',
        title: '🔥 Trio Consistente',
        description: 'Faça pausas por 3 dias seguidos',
        icon: '🔥',
        category: 'streak' as const,
        requirement: 3,
        unlocked: userAchievements.includes('streak_3'),
        progress: Math.min(currentStreak, 3),
        maxProgress: 3,
        reward: { coins: 50, xp: 30 }
      },
      {
        id: 'streak_7',
        title: '⭐ Semana Perfeita',
        description: 'Faça pausas por 7 dias seguidos',
        icon: '⭐',
        category: 'streak' as const,
        requirement: 7,
        unlocked: userAchievements.includes('streak_7'),
        progress: Math.min(currentStreak, 7),
        maxProgress: 7,
        reward: { coins: 100, xp: 75 }
      },
      {
        id: 'streak_30',
        title: '🏆 Mestre da Consistência',
        description: 'Faça pausas por 30 dias seguidos',
        icon: '🏆',
        category: 'streak' as const,
        requirement: 30,
        unlocked: userAchievements.includes('streak_30'),
        progress: Math.min(currentStreak, 30),
        maxProgress: 30,
        reward: { coins: 500, xp: 300 }
      },
      {
        id: 'longest_streak_14',
        title: '💪 Determinação Férrea',
        description: 'Alcance uma sequência de 14 dias',
        icon: '💪',
        category: 'streak' as const,
        requirement: 14,
        unlocked: userAchievements.includes('longest_streak_14'),
        progress: Math.min(longestStreak, 14),
        maxProgress: 14,
        reward: { coins: 200, xp: 150 }
      },

      // Mission Achievements
      {
        id: 'missions_10',
        title: '🎯 Iniciante Dedicado',
        description: 'Complete 10 missões',
        icon: '🎯',
        category: 'missions' as const,
        requirement: 10,
        unlocked: userAchievements.includes('missions_10'),
        progress: Math.min(totalMissions, 10),
        maxProgress: 10,
        reward: { coins: 30, xp: 20 }
      },
      {
        id: 'missions_50',
        title: '🚀 Explorador Ativo',
        description: 'Complete 50 missões',
        icon: '🚀',
        category: 'missions' as const,
        requirement: 50,
        unlocked: userAchievements.includes('missions_50'),
        progress: Math.min(totalMissions, 50),
        maxProgress: 50,
        reward: { coins: 150, xp: 100 }
      },
      {
        id: 'weekly_missions_20',
        title: '⚡ Semana Produtiva',
        description: 'Complete 20 missões em uma semana',
        icon: '⚡',
        category: 'missions' as const,
        requirement: 20,
        unlocked: userAchievements.includes('weekly_missions_20'),
        progress: Math.min(weeklyMissions, 20),
        maxProgress: 20,
        reward: { coins: 80, xp: 60 }
      },

      // Level Achievements
      {
        id: 'level_5',
        title: '🌟 Ascensão Inicial',
        description: 'Alcance o nível 5',
        icon: '🌟',
        category: 'level' as const,
        requirement: 5,
        unlocked: userAchievements.includes('level_5'),
        progress: Math.min(userData.level, 5),
        maxProgress: 5,
        reward: { coins: 40, xp: 25 }
      },
      {
        id: 'level_10',
        title: '👑 Veterano Experiente',
        description: 'Alcance o nível 10',
        icon: '👑',
        category: 'level' as const,
        requirement: 10,
        unlocked: userAchievements.includes('level_10'),
        progress: Math.min(userData.level, 10),
        maxProgress: 10,
        reward: { coins: 100, xp: 50 }
      },
      {
        id: 'level_25',
        title: '🎖️ Mestre Supremo',
        description: 'Alcance o nível 25',
        icon: '🎖️',
        category: 'level' as const,
        requirement: 25,
        unlocked: userAchievements.includes('level_25'),
        progress: Math.min(userData.level, 25),
        maxProgress: 25,
        reward: { coins: 300, xp: 200 }
      },

      // Coin Achievements
      {
        id: 'coins_500',
        title: '💰 Primeira Fortuna',
        description: 'Acumule 500 moedas',
        icon: '💰',
        category: 'coins' as const,
        requirement: 500,
        unlocked: userAchievements.includes('coins_500'),
        progress: Math.min(userData.coins, 500),
        maxProgress: 500,
        reward: { coins: 50, xp: 30 }
      },
      {
        id: 'coins_1000',
        title: '💎 Colecionador Rico',
        description: 'Acumule 1000 moedas',
        icon: '💎',
        category: 'coins' as const,
        requirement: 1000,
        unlocked: userAchievements.includes('coins_1000'),
        progress: Math.min(userData.coins, 1000),
        maxProgress: 1000,
        reward: { coins: 100, xp: 75 }
      },

      // Time Management Achievements
      {
        id: 'daily_limit_respect',
        title: '⏰ Disciplina Digital',
        description: 'Mantenha-se abaixo de 3h por 5 dias',
        icon: '⏰',
        category: 'time' as const,
        requirement: 5,
        unlocked: userAchievements.includes('daily_limit_respect'),
        progress: userData.weeklyData
          .slice(-7)
          .filter(d => d.screenTime <= 180).length,
        maxProgress: 5,
        reward: { coins: 120, xp: 80 }
      }
    ];
  }, [userData]);

  const unlockedAchievements = achievements.filter(a => a.unlocked);
  const availableAchievements = achievements.filter(a => !a.unlocked && a.progress < a.maxProgress);
  const completedAchievements = achievements.filter(a => !a.unlocked && a.progress >= a.maxProgress);

  return {
    achievements,
    unlockedAchievements,
    availableAchievements,
    completedAchievements
  };
}