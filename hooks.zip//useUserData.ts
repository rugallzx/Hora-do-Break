import { useState, useEffect } from 'react';
import { createUserDataHash } from '../components/SecurityManager';

interface UserData {
  dailyScreenTime: number;
  coins: number;
  level: number;
  xp: number;
  avatarConfig: {
    body: string;
    eyes: string;
    accessory: string;
    hair?: string;
  };
  lastBreakTime: number;
  sessionStartTime: number;
  weeklyData: Array<{
    date: string;
    screenTime: number;
    missionsCompleted: number;
  }>;
  completedMissions: string[];
  lastSync?: string;
  integrityHash?: string;
  lastValidation?: number;
  streakData?: {
    currentStreak: number;
    longestStreak: number;
    lastBreakDate: string;
  };
  achievements?: string[];
}

export function useUserData() {
  const getInitialUserData = (): UserData => {
    try {
      if (typeof window !== 'undefined' && typeof localStorage !== 'undefined') {
        const saved = localStorage.getItem('screenTimeApp');
        if (saved) {
          const parsed = JSON.parse(saved);
          // Garantir que os novos campos existam
          return {
            ...parsed,
            streakData: parsed.streakData || {
              currentStreak: 0,
              longestStreak: 0,
              lastBreakDate: ''
            },
            achievements: parsed.achievements || []
          };
        }
      }
    } catch (error) {
      console.error('Error loading saved data:', error);
    }
    
    return {
      dailyScreenTime: 0,
      coins: 200,
      level: 1,
      xp: 0,
      avatarConfig: { body: 'happy', eyes: 'normal', accessory: 'none', hair: 'none' },
      lastBreakTime: Date.now(),
      sessionStartTime: Date.now(),
      weeklyData: [],
      completedMissions: [],
      streakData: {
        currentStreak: 0,
        longestStreak: 0,
        lastBreakDate: ''
      },
      achievements: []
    };
  };

  const [userData, setUserData] = useState<UserData>(getInitialUserData);

  // Salvar dados automaticamente
  useEffect(() => {
    try {
      if (typeof window !== 'undefined' && typeof localStorage !== 'undefined') {
        const dataWithIntegrity = {
          ...userData,
          integrityHash: createUserDataHash(userData),
          lastValidation: Date.now()
        };
        localStorage.setItem('screenTimeApp', JSON.stringify(dataWithIntegrity));
      }
    } catch (error) {
      console.error('Error saving data to localStorage:', error);
    }
  }, [userData]);

  // Atualizar dados semanais automaticamente
  useEffect(() => {
    const saveWeeklyData = () => {
      try {
        const today = new Date().toISOString().split('T')[0];
        const existingDataIndex = userData.weeklyData?.findIndex(d => d.date === today) ?? -1;
        
        const todayData = {
          date: today,
          screenTime: userData.dailyScreenTime,
          missionsCompleted: userData.completedMissions.length
        };

        setUserData(prev => {
          const newWeeklyData = [...(prev.weeklyData || [])];
          
          if (existingDataIndex >= 0) {
            newWeeklyData[existingDataIndex] = todayData;
          } else {
            newWeeklyData.push(todayData);
          }

          // Manter apenas os últimos 30 dias
          const thirtyDaysAgo = new Date();
          thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
          const filteredData = newWeeklyData.filter(d => 
            new Date(d.date) >= thirtyDaysAgo
          );

          return {
            ...prev,
            weeklyData: filteredData
          };
        });
      } catch (error) {
        console.error('Error saving weekly data:', error);
      }
    };

    const saveInterval = window.setInterval(saveWeeklyData, 5 * 60 * 1000);
    
    return () => {
      if (saveInterval) {
        window.clearInterval(saveInterval);
      }
    };
  }, [userData.dailyScreenTime, userData.completedMissions.length]);

  const updateUserData = (updater: (prev: UserData) => UserData) => {
    setUserData(updater);
  };

  return { userData, updateUserData };
}