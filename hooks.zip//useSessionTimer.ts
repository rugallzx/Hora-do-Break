import { useState, useEffect } from 'react';

export function useSessionTimer(sessionStartTime: number, lastBreakTime: number) {
  const [currentSessionTime, setCurrentSessionTime] = useState(0);
  const [showBreakDialog, setShowBreakDialog] = useState(false);

  useEffect(() => {
    let interval: number | undefined;
    
    try {
      interval = window.setInterval(() => {
        const sessionDuration = Date.now() - sessionStartTime;
        setCurrentSessionTime(Math.floor(sessionDuration / (1000 * 60))); // em minutos

        // Verificar se precisa de pausa após 40 minutos
        if (sessionDuration > 40 * 60 * 1000 && Date.now() - lastBreakTime > 40 * 60 * 1000) {
          setShowBreakDialog(true);
        }
      }, 1000);
    } catch (error) {
      console.error('Error setting up session timer:', error);
    }

    return () => {
      if (interval) {
        window.clearInterval(interval);
      }
    };
  }, [sessionStartTime, lastBreakTime]);

  return { currentSessionTime, showBreakDialog, setShowBreakDialog };
}