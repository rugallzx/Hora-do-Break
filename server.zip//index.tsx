import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { logger } from 'npm:hono/logger';
import { createClient } from 'npm:@supabase/supabase-js@2';
import * as kv from './kv_store.tsx';

const app = new Hono();

// Configure CORS and logger
app.use('*', cors({
  origin: ['http://localhost:3000', 'https://supabase.com'],
  allowHeaders: ['Content-Type', 'Authorization'],
  allowMethods: ['POST', 'GET', 'PUT', 'DELETE', 'OPTIONS'],
}));

app.use('*', logger(console.log));

// Initialize Supabase client
const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
);

// User registration
app.post('/make-server-187b714d/auth/signup', async (c) => {
  try {
    const { email, password, name } = await c.req.json();

    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true
    });

    if (error) {
      console.log('Signup error:', error);
      return c.json({ error: error.message }, 400);
    }

    // Initialize user data in KV store
    const initialUserData = {
      dailyScreenTime: 0,
      coins: 100,
      level: 1,
      xp: 0,
      avatarConfig: { body: 'happy', eyes: 'normal', accessory: 'none' },
      lastBreakTime: Date.now(),
      sessionStartTime: Date.now(),
      weeklyData: [],
      completedMissions: [],
      createdAt: new Date().toISOString(),
      lastSync: new Date().toISOString()
    };

    await kv.set(`user_${data.user.id}`, initialUserData);

    return c.json({ 
      user: data.user,
      message: 'User created successfully' 
    });

  } catch (error) {
    console.log('Signup server error:', error);
    return c.json({ error: 'Internal server error during signup' }, 500);
  }
});

// Sync user data
app.post('/make-server-187b714d/sync', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const body = await c.req.json();
    const { userData, action } = body;

    if (action === 'upload') {
      // Upload local data to server
      userData.lastSync = new Date().toISOString();
      await kv.set(`user_${user.id}`, userData);
      
      return c.json({ 
        success: true, 
        message: 'Data synced to server',
        lastSync: userData.lastSync 
      });

    } else if (action === 'download') {
      // Download server data
      const serverData = await kv.get(`user_${user.id}`);
      
      if (!serverData) {
        // Initialize if no server data exists
        const initialData = {
          dailyScreenTime: 0,
          coins: 100,
          level: 1,
          xp: 0,
          avatarConfig: { body: 'happy', eyes: 'normal', accessory: 'none' },
          lastBreakTime: Date.now(),
          sessionStartTime: Date.now(),
          weeklyData: [],
          completedMissions: [],
          createdAt: new Date().toISOString(),
          lastSync: new Date().toISOString()
        };
        await kv.set(`user_${user.id}`, initialData);
        return c.json({ userData: initialData });
      }

      return c.json({ userData: serverData });

    } else if (action === 'merge') {
      // Smart merge of local and server data
      const serverData = await kv.get(`user_${user.id}`) || {};
      const localLastSync = new Date(userData.lastSync || 0);
      const serverLastSync = new Date(serverData.lastSync || 0);

      let mergedData;
      if (localLastSync > serverLastSync) {
        // Local data is newer
        mergedData = { ...serverData, ...userData };
      } else {
        // Server data is newer or equal
        mergedData = { ...userData, ...serverData };
      }

      mergedData.lastSync = new Date().toISOString();
      await kv.set(`user_${user.id}`, mergedData);

      return c.json({ 
        userData: mergedData,
        message: 'Data merged successfully' 
      });
    }

    return c.json({ error: 'Invalid action' }, 400);

  } catch (error) {
    console.log('Sync error:', error);
    return c.json({ error: 'Internal server error during sync' }, 500);
  }
});

// Get user profile
app.get('/make-server-187b714d/profile', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const userData = await kv.get(`user_${user.id}`);
    
    return c.json({ 
      user: {
        id: user.id,
        email: user.email,
        name: user.user_metadata?.name
      },
      userData 
    });

  } catch (error) {
    console.log('Profile fetch error:', error);
    return c.json({ error: 'Internal server error fetching profile' }, 500);
  }
});

// Update device screen time data
app.post('/make-server-187b714d/screen-time', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { screenTimeData, deviceId } = await c.req.json();
    
    // Store device-specific screen time data
    const key = `screen_time_${user.id}_${deviceId}`;
    const existingData = await kv.get(key) || [];
    
    // Add new screen time entry
    existingData.push({
      ...screenTimeData,
      timestamp: new Date().toISOString()
    });

    // Keep only last 30 days of data
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    
    const filteredData = existingData.filter(entry => 
      new Date(entry.timestamp) > thirtyDaysAgo
    );

    await kv.set(key, filteredData);
    
    return c.json({ 
      success: true,
      message: 'Screen time data saved',
      dataPoints: filteredData.length
    });

  } catch (error) {
    console.log('Screen time update error:', error);
    return c.json({ error: 'Internal server error updating screen time' }, 500);
  }
});

// Get aggregated screen time data
app.get('/make-server-187b714d/screen-time', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    // Get all screen time data for user across devices
    const keys = await kv.getByPrefix(`screen_time_${user.id}_`);
    
    let allData = [];
    for (const key of keys) {
      const deviceData = await kv.get(key);
      if (Array.isArray(deviceData)) {
        allData = allData.concat(deviceData);
      }
    }

    // Sort by timestamp
    allData.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
    
    return c.json({ 
      screenTimeData: allData.slice(0, 100) // Last 100 entries
    });

  } catch (error) {
    console.log('Screen time fetch error:', error);
    return c.json({ error: 'Internal server error fetching screen time' }, 500);
  }
});

// Health check
app.get('/make-server-187b714d/health', (c) => {
  return c.json({ status: 'ok', timestamp: new Date().toISOString() });
});

Deno.serve(app.fetch);