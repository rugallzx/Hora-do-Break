import React from 'react';
import { Badge } from './ui/badge';
import { Cloud, CloudOff, Bell, BellOff, Wifi, WifiOff, Activity } from 'lucide-react';

interface StatusIndicatorProps {
  isAuthenticated: boolean;
  userName?: string;
  notificationEnabled: boolean;
  isOnline: boolean;
  lastSync?: string;
}

export function StatusIndicator({ 
  isAuthenticated, 
  userName, 
  notificationEnabled, 
  isOnline,
  lastSync 
}: StatusIndicatorProps) {
  const getTimeAgo = (timestamp?: string) => {
    if (!timestamp) return 'Nunca';
    const now = new Date();
    const sync = new Date(timestamp);
    const diffInMs = now.getTime() - sync.getTime();
    const diffInMinutes = Math.floor(diffInMs / (1000 * 60));
    
    if (diffInMinutes < 1) return 'Agora';
    if (diffInMinutes < 60) return `${diffInMinutes}m atrás`;
    const diffInHours = Math.floor(diffInMinutes / 60);
    if (diffInHours < 24) return `${diffInHours}h atrás`;
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays}d atrás`;
  };

  return (
    <div className="flex flex-wrap justify-center gap-2 text-xs">
      {/* Authentication Status */}
      <Badge 
        variant={isAuthenticated ? "default" : "outline"} 
        className={`transition-all duration-200 ${
          isAuthenticated 
            ? "bg-gradient-to-r from-green-500 to-emerald-500 hover:shadow-lg" 
            : "border-gray-300 hover:border-gray-400"
        }`}
      >
        {isAuthenticated ? (
          <>
            <Cloud className="h-3 w-3 mr-1" />
            <span className="hidden sm:inline">{userName || 'Conectado'}</span>
            <span className="sm:hidden">On</span>
          </>
        ) : (
          <>
            <CloudOff className="h-3 w-3 mr-1" />
            <span className="hidden sm:inline">Offline</span>
            <span className="sm:hidden">Off</span>
          </>
        )}
      </Badge>

      {/* Notification Status */}
      <Badge 
        variant="outline" 
        className={`transition-all duration-200 ${
          notificationEnabled 
            ? "border-blue-300 text-blue-700 bg-blue-50 hover:bg-blue-100" 
            : "border-gray-300 text-gray-500"
        }`}
      >
        {notificationEnabled ? (
          <>
            <Bell className="h-3 w-3 mr-1" />
            <span className="hidden sm:inline">Notificações</span>
            <span className="sm:hidden">🔔</span>
          </>
        ) : (
          <>
            <BellOff className="h-3 w-3 mr-1" />
            <span className="hidden sm:inline">Silencioso</span>
            <span className="sm:hidden">🔕</span>
          </>
        )}
      </Badge>

      {/* Network Status */}
      <Badge 
        variant="outline" 
        className={`transition-all duration-200 ${
          isOnline 
            ? "border-green-300 text-green-700 bg-green-50" 
            : "border-red-300 text-red-600 bg-red-50"
        }`}
      >
        {isOnline ? (
          <>
            <Wifi className="h-3 w-3 mr-1" />
            <span className="hidden sm:inline">Online</span>
            <span className="sm:hidden">📶</span>
          </>
        ) : (
          <>
            <WifiOff className="h-3 w-3 mr-1" />
            <span className="hidden sm:inline">Offline</span>
            <span className="sm:hidden">📵</span>
          </>
        )}
      </Badge>

      {/* Sync Status */}
      {isAuthenticated && (
        <Badge 
          variant="outline" 
          className="border-purple-300 text-purple-700 bg-purple-50 hover:bg-purple-100 transition-all duration-200"
          title={`Último sync: ${getTimeAgo(lastSync)}`}
        >
          <Activity className="h-3 w-3 mr-1" />
          <span className="hidden sm:inline">Sync: {getTimeAgo(lastSync)}</span>
          <span className="sm:hidden">📊</span>
        </Badge>
      )}
    </div>
  );
}