import React from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { CheckCircle, Clock, Target, Award } from 'lucide-react';

interface Mission {
  id: string;
  title: string;
  description: string;
  type: 'daily' | 'weekly' | 'achievement';
  target: number;
  current: number;
  reward: number;
  icon: any;
  completed: boolean;
}

interface MissionsProps {
  userData: any;
  onMissionComplete: (missionId: string, reward: number) => void;
}

export function Missions({ userData, onMissionComplete }: MissionsProps) {
  const checkMissionCompletion = (mission: Mission) => {
    if (!mission.completed && mission.current >= mission.target) {
      onMissionComplete(mission.id, mission.reward);
      return true;
    }
    return false;
  };

  const missions: Mission[] = [
    {
      id: 'daily_limit',
      title: 'Limite Diário',
      description: 'Finalize o dia com menos de 3h de tempo de tela',
      type: 'daily',
      target: 180, // 3 horas em minutos
      current: userData.dailyScreenTime,
      reward: 50,
      icon: Target,
      completed: userData.completedMissions.includes('daily_limit')
    },
    {
      id: 'break_warrior',
      title: 'Guerreiro das Pausas',
      description: 'Faça 5 pausas de 5 minutos hoje',
      type: 'daily',
      target: 5,
      current: Math.floor(userData.xp / 15), // Assumindo que cada pausa dá 15 XP
      reward: 30,
      icon: Clock,
      completed: userData.completedMissions.includes('break_warrior')
    },
    {
      id: 'early_bird',
      title: 'Madrugador Digital',
      description: 'Não use telas nas primeiras 2 horas do dia',
      type: 'daily',
      target: 1,
      current: new Date().getHours() >= 8 ? 1 : 0, // Simula se passou das 8h
      reward: 40,
      icon: Award,
      completed: userData.completedMissions.includes('early_bird')
    },
    {
      id: 'week_champion',
      title: 'Campeão Semanal',
      description: 'Complete todas as missões diárias por 7 dias',
      type: 'weekly',
      target: 7,
      current: userData.weeklyData?.filter(day => day.missionsCompleted >= 2).length || 0,
      reward: 100,
      icon: Award,
      completed: userData.completedMissions.includes('week_champion')
    },
    {
      id: 'balance_master',
      title: 'Mestre do Equilíbrio',
      description: 'Mantenha menos de 2h de tela por 3 dias seguidos',
      type: 'achievement',
      target: 3,
      current: 0, // Seria calculado baseado no histórico
      reward: 75,
      icon: Target,
      completed: userData.completedMissions.includes('balance_master')
    },
    {
      id: 'coin_collector',
      title: 'Colecionador de Moedas',
      description: 'Acumule 500 moedas',
      type: 'achievement',
      target: 500,
      current: userData.coins,
      reward: 0, // Não dá recompensa adicional
      icon: Award,
      completed: userData.coins >= 500
    }
  ];

  const dailyMissions = missions.filter(m => m.type === 'daily');
  const weeklyMissions = missions.filter(m => m.type === 'weekly');
  const achievements = missions.filter(m => m.type === 'achievement');

  const renderMission = (mission: Mission) => {
    const progress = Math.min((mission.current / mission.target) * 100, 100);
    const isCompleted = mission.completed || checkMissionCompletion(mission);
    const Icon = mission.icon;

    return (
      <Card key={mission.id} className={`p-4 ${isCompleted ? 'bg-green-50 border-green-200' : ''}`}>
        <div className="flex items-start space-x-3">
          <div className={`p-2 rounded-full ${isCompleted ? 'bg-green-500' : 'bg-blue-500'}`}>
            {isCompleted ? (
              <CheckCircle className="h-4 w-4 text-white" />
            ) : (
              <Icon className="h-4 w-4 text-white" />
            )}
          </div>

          <div className="flex-1 space-y-2">
            <div className="flex justify-between items-start">
              <div>
                <h4 className={isCompleted ? 'line-through text-muted-foreground' : ''}>{mission.title}</h4>
                <p className="text-sm text-muted-foreground">{mission.description}</p>
              </div>
              {mission.reward > 0 && (
                <Badge variant={isCompleted ? 'default' : 'secondary'}>
                  +{mission.reward} moedas
                </Badge>
              )}
            </div>

            {!isCompleted && (
              <div className="space-y-1">
                <div className="flex justify-between text-sm">
                  <span>Progresso</span>
                  <span>{mission.current}/{mission.target}</span>
                </div>
                <Progress value={progress} className="h-2" />
              </div>
            )}

            {isCompleted && (
              <Badge variant="default" className="bg-green-500">
                ✓ Concluída
              </Badge>
            )}
          </div>
        </div>
      </Card>
    );
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2>Missões e Desafios</h2>
        <p className="text-muted-foreground">
          Complete missões para ganhar moedas e subir de nível!
        </p>
      </div>

      {/* Missões Diárias */}
      <div className="space-y-3">
        <div className="flex items-center space-x-2">
          <Clock className="h-5 w-5 text-blue-500" />
          <h3>Missões Diárias</h3>
          <Badge variant="outline">
            {dailyMissions.filter(m => m.completed).length}/{dailyMissions.length}
          </Badge>
        </div>
        <div className="grid gap-3">
          {dailyMissions.map(renderMission)}
        </div>
      </div>

      {/* Missões Semanais */}
      <div className="space-y-3">
        <div className="flex items-center space-x-2">
          <Target className="h-5 w-5 text-purple-500" />
          <h3>Desafios Semanais</h3>
          <Badge variant="outline">
            {weeklyMissions.filter(m => m.completed).length}/{weeklyMissions.length}
          </Badge>
        </div>
        <div className="grid gap-3">
          {weeklyMissions.map(renderMission)}
        </div>
      </div>

      {/* Conquistas */}
      <div className="space-y-3">
        <div className="flex items-center space-x-2">
          <Award className="h-5 w-5 text-yellow-500" />
          <h3>Conquistas</h3>
          <Badge variant="outline">
            {achievements.filter(m => m.completed).length}/{achievements.length}
          </Badge>
        </div>
        <div className="grid gap-3">
          {achievements.map(renderMission)}
        </div>
      </div>

      {/* Dicas */}
      <Card className="p-4 bg-blue-50 border-blue-200">
        <h4 className="flex items-center space-x-2 mb-2">
          <Award className="h-4 w-4 text-blue-500" />
          <span>Dicas para Completar Missões</span>
        </h4>
        <ul className="text-sm text-muted-foreground space-y-1">
          <li>• Configure lembretes para fazer pausas regulares</li>
          <li>• Use o modo não perturbe durante pausas</li>
          <li>• Mantenha atividades offline preparadas para as pausas</li>
          <li>• Comemore cada missão completada!</li>
        </ul>
      </Card>
    </div>
  );
}