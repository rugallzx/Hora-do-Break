import React, { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { toast } from 'sonner@2.0.3';
import { Coffee, Mail, Lock, User, Eye, EyeOff, Shield, Sparkles, Trophy, Coins } from 'lucide-react';

interface AuthUser {
  id: string;
  email: string;
  name: string;
}

interface AuthScreenProps {
  onAuthSuccess: (user: AuthUser) => void;
  onSkip: () => void;
}

export function AuthScreen({ onAuthSuccess, onSkip }: AuthScreenProps) {
  const [activeTab, setActiveTab] = useState<'login' | 'register'>('login');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: ''
  });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const validateEmail = (email: string) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const validatePassword = (password: string) => {
    return password.length >= 6;
  };

  const handleLogin = async () => {
    if (!formData.email || !formData.password) {
      toast.error('Por favor, preencha todos os campos');
      return;
    }

    if (!validateEmail(formData.email)) {
      toast.error('Por favor, insira um email válido');
      return;
    }

    setIsLoading(true);

    try {
      // Simular chamada de API
      await new Promise(resolve => setTimeout(resolve, 1500));

      // Simular autenticação (em produção, usar Supabase ou outro serviço)
      const user: AuthUser = {
        id: 'user_' + Math.random().toString(36).substr(2, 9),
        email: formData.email,
        name: formData.email.split('@')[0]
      };

      // Salvar no localStorage (em produção, usar tokens seguros)
      localStorage.setItem('authUser', JSON.stringify(user));
      localStorage.setItem('authToken', 'token_' + Math.random().toString(36));

      toast.success(`🎉 Bem-vindo de volta, ${user.name}!`, {
        description: 'Login realizado com sucesso. Vamos continuar sua jornada!'
      });

      onAuthSuccess(user);
    } catch (error) {
      toast.error('Erro ao fazer login. Tente novamente.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleRegister = async () => {
    if (!formData.name || !formData.email || !formData.password || !formData.confirmPassword) {
      toast.error('Por favor, preencha todos os campos');
      return;
    }

    if (!validateEmail(formData.email)) {
      toast.error('Por favor, insira um email válido');
      return;
    }

    if (!validatePassword(formData.password)) {
      toast.error('A senha deve ter pelo menos 6 caracteres');
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      toast.error('As senhas não coincidem');
      return;
    }

    setIsLoading(true);

    try {
      // Simular chamada de API
      await new Promise(resolve => setTimeout(resolve, 2000));

      // Simular criação de conta
      const user: AuthUser = {
        id: 'user_' + Math.random().toString(36).substr(2, 9),
        email: formData.email,
        name: formData.name
      };

      // Salvar no localStorage
      localStorage.setItem('authUser', JSON.stringify(user));
      localStorage.setItem('authToken', 'token_' + Math.random().toString(36));

      toast.success(`🎉 Conta criada com sucesso, ${user.name}!`, {
        description: 'Você ganhou 50 moedas de bônus para começar!'
      });

      onAuthSuccess(user);
    } catch (error) {
      toast.error('Erro ao criar conta. Tente novamente.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="mx-auto w-20 h-20 bg-gradient-to-br from-orange-500 to-yellow-500 rounded-full flex items-center justify-center shadow-lg">
            <Coffee className="h-10 w-10 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-orange-600 to-yellow-600 bg-clip-text text-transparent">
              Hora do Break
            </h1>
            <p className="text-gray-600 mt-2">
              ☕ Transforme suas pausas em momentos recompensadores
            </p>
          </div>
        </div>

        {/* Benefits Cards */}
        <div className="grid grid-cols-3 gap-2 mb-6">
          <div className="bg-white/70 rounded-lg p-3 text-center border">
            <Trophy className="h-5 w-5 text-purple-500 mx-auto mb-1" />
            <p className="text-xs text-purple-700 font-medium">Missões</p>
          </div>
          <div className="bg-white/70 rounded-lg p-3 text-center border">
            <Coins className="h-5 w-5 text-yellow-500 mx-auto mb-1" />
            <p className="text-xs text-yellow-700 font-medium">Recompensas</p>
          </div>
          <div className="bg-white/70 rounded-lg p-3 text-center border">
            <Sparkles className="h-5 w-5 text-pink-500 mx-auto mb-1" />
            <p className="text-xs text-pink-700 font-medium">Avatar</p>
          </div>
        </div>

        {/* Auth Tabs */}
        <Card className="p-6 bg-white/80 backdrop-blur-sm border shadow-xl">
          <Tabs value={activeTab} onValueChange={(value: any) => setActiveTab(value)}>
            <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger 
                value="login"
                className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-500 data-[state=active]:to-purple-500 data-[state=active]:text-white"
              >
                Entrar
              </TabsTrigger>
              <TabsTrigger 
                value="register"
                className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-green-500 data-[state=active]:to-emerald-500 data-[state=active]:text-white"
              >
                Criar Conta
              </TabsTrigger>
            </TabsList>

            <TabsContent value="login" className="space-y-4">
              <div className="space-y-3">
                <div>
                  <Label htmlFor="login-email" className="flex items-center space-x-2 text-sm text-gray-700">
                    <Mail className="h-4 w-4" />
                    <span>Email</span>
                  </Label>
                  <Input
                    id="login-email"
                    type="email"
                    placeholder="seu@email.com"
                    value={formData.email}
                    onChange={(e) => handleInputChange('email', e.target.value)}
                    className="mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="login-password" className="flex items-center space-x-2 text-sm text-gray-700">
                    <Lock className="h-4 w-4" />
                    <span>Senha</span>
                  </Label>
                  <div className="relative mt-1">
                    <Input
                      id="login-password"
                      type={showPassword ? 'text' : 'password'}
                      placeholder="Sua senha"
                      value={formData.password}
                      onChange={(e) => handleInputChange('password', e.target.value)}
                      className="pr-10"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute inset-y-0 right-0 pr-3 flex items-center"
                    >
                      {showPassword ? (
                        <EyeOff className="h-4 w-4 text-gray-400" />
                      ) : (
                        <Eye className="h-4 w-4 text-gray-400" />
                      )}
                    </button>
                  </div>
                </div>
              </div>

              <Button 
                onClick={handleLogin}
                disabled={isLoading}
                className="w-full bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white shadow-lg"
              >
                {isLoading ? (
                  <div className="flex items-center space-x-2">
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    <span>Entrando...</span>
                  </div>
                ) : (
                  'Entrar'
                )}
              </Button>
            </TabsContent>

            <TabsContent value="register" className="space-y-4">
              <div className="space-y-3">
                <div>
                  <Label htmlFor="register-name" className="flex items-center space-x-2 text-sm text-gray-700">
                    <User className="h-4 w-4" />
                    <span>Nome</span>
                  </Label>
                  <Input
                    id="register-name"
                    type="text"
                    placeholder="Seu nome"
                    value={formData.name}
                    onChange={(e) => handleInputChange('name', e.target.value)}
                    className="mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="register-email" className="flex items-center space-x-2 text-sm text-gray-700">
                    <Mail className="h-4 w-4" />
                    <span>Email</span>
                  </Label>
                  <Input
                    id="register-email"
                    type="email"
                    placeholder="seu@email.com"
                    value={formData.email}
                    onChange={(e) => handleInputChange('email', e.target.value)}
                    className="mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="register-password" className="flex items-center space-x-2 text-sm text-gray-700">
                    <Lock className="h-4 w-4" />
                    <span>Senha</span>
                  </Label>
                  <div className="relative mt-1">
                    <Input
                      id="register-password"
                      type={showPassword ? 'text' : 'password'}
                      placeholder="Mínimo 6 caracteres"
                      value={formData.password}
                      onChange={(e) => handleInputChange('password', e.target.value)}
                      className="pr-10"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute inset-y-0 right-0 pr-3 flex items-center"
                    >
                      {showPassword ? (
                        <EyeOff className="h-4 w-4 text-gray-400" />
                      ) : (
                        <Eye className="h-4 w-4 text-gray-400" />
                      )}
                    </button>
                  </div>
                </div>

                <div>
                  <Label htmlFor="register-confirm-password" className="flex items-center space-x-2 text-sm text-gray-700">
                    <Shield className="h-4 w-4" />
                    <span>Confirmar Senha</span>
                  </Label>
                  <div className="relative mt-1">
                    <Input
                      id="register-confirm-password"
                      type={showConfirmPassword ? 'text' : 'password'}
                      placeholder="Digite a senha novamente"
                      value={formData.confirmPassword}
                      onChange={(e) => handleInputChange('confirmPassword', e.target.value)}
                      className="pr-10"
                    />
                    <button
                      type="button"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      className="absolute inset-y-0 right-0 pr-3 flex items-center"
                    >
                      {showConfirmPassword ? (
                        <EyeOff className="h-4 w-4 text-gray-400" />
                      ) : (
                        <Eye className="h-4 w-4 text-gray-400" />
                      )}
                    </button>
                  </div>
                </div>
              </div>

              {/* Bônus para novos usuários */}
              <div className="bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-lg p-3">
                <div className="flex items-center space-x-2 mb-1">
                  <span className="text-lg">🎁</span>
                  <span className="font-medium text-green-800">Bônus de Boas-vindas</span>
                </div>
                <p className="text-sm text-green-700">
                  Ganhe <strong>50 moedas</strong> e <strong>25 XP</strong> ao criar sua conta!
                </p>
              </div>

              <Button 
                onClick={handleRegister}
                disabled={isLoading}
                className="w-full bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white shadow-lg"
              >
                {isLoading ? (
                  <div className="flex items-center space-x-2">
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    <span>Criando conta...</span>
                  </div>
                ) : (
                  'Criar Conta'
                )}
              </Button>
            </TabsContent>
          </Tabs>
        </Card>

        {/* Skip Option */}
        <div className="text-center space-y-3">
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-300"></div>
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 text-gray-500">ou</span>
            </div>
          </div>
          
          <Button 
            variant="outline" 
            onClick={onSkip}
            className="w-full border-gray-300 text-gray-600 hover:bg-gray-50"
          >
            Continuar sem conta
          </Button>
          
          <p className="text-xs text-gray-500">
            💡 Dica: Com uma conta você pode sincronizar seus dados entre dispositivos
          </p>
        </div>

        {/* Features */}
        <div className="text-center">
          <div className="flex justify-center space-x-4 text-xs text-gray-500">
            <Badge variant="outline" className="bg-white/70">
              🔒 Dados Seguros
            </Badge>
            <Badge variant="outline" className="bg-white/70">
              🌟 Gamificado
            </Badge>
            <Badge variant="outline" className="bg-white/70">
              💻 Multi-dispositivo
            </Badge>
          </div>
        </div>
      </div>
    </div>
  );
}