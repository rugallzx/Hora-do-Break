import React, { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { motion, AnimatePresence } from 'motion/react';
import { useAchievements, Achievement } from '../hooks/useAchievements';
import { Trophy, Star, Award, Gift, CheckCircle } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface AchievementsPanelProps {
  userData: any;
  onClaimReward: (achievement: Achievement) => void;
}

export function AchievementsPanel({ userData, onClaimReward }: AchievementsPanelProps) {
  const { achievements, unlockedAchievements, availableAchievements, completedAchievements } = useAchievements(userData);
  const [selectedAchievement, setSelectedAchievement] = useState<Achievement | null>(null);
  const [activeTab, setActiveTab] = useState<'progress' | 'unlocked'>('progress');

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'streak': return '🔥';
      case 'missions': return '🎯';
      case 'level': return '⭐';
      case 'time': return '⏰';
      case 'coins': return '💰';
      default: return '🏆';
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'streak': return 'from-red-500 to-orange-500';
      case 'missions': return 'from-blue-500 to-cyan-500';
      case 'level': return 'from-purple-500 to-pink-500';
      case 'time': return 'from-green-500 to-emerald-500';
      case 'coins': return 'from-yellow-500 to-amber-500';
      default: return 'from-gray-500 to-slate-500';
    }
  };

  const handleClaimReward = (achievement: Achievement) => {
    onClaimReward(achievement);
    setSelectedAchievement(null);
    
    // Animação de celebração
    toast.success(`🎉 Conquista desbloqueada: ${achievement.title}!`, {
      description: `Você ganhou ${achievement.reward.coins} moedas e ${achievement.reward.xp} XP!`,
      duration: 5000,
    });
  };

  return (
    <div className="space-y-6">
      {/* Header com estatísticas */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center space-x-2">
          <div className="p-3 bg-gradient-to-br from-yellow-500 to-orange-500 rounded-full shadow-lg">
            <Trophy className="h-6 w-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold bg-gradient-to-r from-yellow-600 to-orange-600 bg-clip-text text-transparent">
              Conquistas
            </h2>
            <p className="text-sm text-muted-foreground">
              {unlockedAchievements.length} de {achievements.length} desbloqueadas
            </p>
          </div>
        </div>

        {/* Estatísticas rápidas */}
        <div className="flex justify-center space-x-6">
          <div className="text-center">
            <div className="text-xl font-bold text-yellow-600">{unlockedAchievements.length}</div>
            <div className="text-xs text-muted-foreground">Desbloqueadas</div>
          </div>
          <div className="text-center">
            <div className="text-xl font-bold text-blue-600">{completedAchievements.length}</div>
            <div className="text-xs text-muted-foreground">Para coletar</div>
          </div>
          <div className="text-center">
            <div className="text-xl font-bold text-green-600">{availableAchievements.length}</div>
            <div className="text-xs text-muted-foreground">Em progresso</div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex justify-center">
        <div className="bg-muted p-1 rounded-lg inline-flex">
          <Button
            variant={activeTab === 'progress' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setActiveTab('progress')}
            className="transition-all duration-200"
          >
            <Star className="h-4 w-4 mr-1" />
            Em Progresso
          </Button>
          <Button
            variant={activeTab === 'unlocked' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setActiveTab('unlocked')}
            className="transition-all duration-200"
          >
            <Award className="h-4 w-4 mr-1" />
            Desbloqueadas
          </Button>
        </div>
      </div>

      {/* Conquistas que podem ser coletadas */}
      {completedAchievements.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-2"
        >
          <h3 className="font-medium text-green-700 dark:text-green-400 flex items-center">
            <Gift className="h-4 w-4 mr-2" />
            Pronto para coletar! 🎁
          </h3>
          <div className="grid gap-3">
            {completedAchievements.map((achievement) => (
              <motion.div
                key={achievement.id}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <Card className="p-4 border-2 border-green-200 dark:border-green-800 bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-950 dark:to-emerald-950 cursor-pointer hover:shadow-lg transition-all duration-200"
                      onClick={() => setSelectedAchievement(achievement)}>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className={`p-2 rounded-full bg-gradient-to-r ${getCategoryColor(achievement.category)} text-white shadow-lg`}>
                        <span className="text-lg">{achievement.icon}</span>
                      </div>
                      <div>
                        <h4 className="font-medium text-green-800 dark:text-green-200">{achievement.title}</h4>
                        <p className="text-sm text-green-600 dark:text-green-400">{achievement.description}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge className="bg-green-600 text-white animate-pulse">
                        Coletar!
                      </Badge>
                      <CheckCircle className="h-5 w-5 text-green-600" />
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>
      )}

      {/* Lista de conquistas */}
      <div className="grid gap-3">
        <AnimatePresence mode="wait">
          {activeTab === 'progress' && (
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="space-y-3"
            >
              {availableAchievements.map((achievement) => (
                <motion.div
                  key={achievement.id}
                  whileHover={{ scale: 1.01 }}
                  whileTap={{ scale: 0.99 }}
                >
                  <Card className="p-4 hover:shadow-md transition-all duration-200 cursor-pointer"
                        onClick={() => setSelectedAchievement(achievement)}>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className={`p-2 rounded-full bg-gradient-to-r ${getCategoryColor(achievement.category)} text-white shadow-md opacity-80`}>
                            <span className="text-sm">{achievement.icon}</span>
                          </div>
                          <div>
                            <h4 className="font-medium">{achievement.title}</h4>
                            <p className="text-sm text-muted-foreground">{achievement.description}</p>
                          </div>
                        </div>
                        <Badge variant="outline" className="text-xs">
                          {achievement.progress}/{achievement.maxProgress}
                        </Badge>
                      </div>
                      
                      <div className="space-y-1">
                        <div className="flex justify-between text-xs text-muted-foreground">
                          <span>Progresso</span>
                          <span>{Math.round((achievement.progress / achievement.maxProgress) * 100)}%</span>
                        </div>
                        <Progress 
                          value={(achievement.progress / achievement.maxProgress) * 100} 
                          className="h-2"
                        />
                      </div>
                    </div>
                  </Card>
                </motion.div>
              ))}
            </motion.div>
          )}

          {activeTab === 'unlocked' && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-3"
            >
              {unlockedAchievements.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Trophy className="h-12 w-12 mx-auto mb-3 opacity-50" />
                  <p>Nenhuma conquista desbloqueada ainda</p>
                  <p className="text-sm">Continue fazendo pausas para desbloquear!</p>
                </div>
              ) : (
                unlockedAchievements.map((achievement) => (
                  <motion.div
                    key={achievement.id}
                    whileHover={{ scale: 1.01 }}
                  >
                    <Card className="p-4 bg-gradient-to-r from-yellow-50 to-orange-50 dark:from-yellow-950 dark:to-orange-950 border-yellow-200 dark:border-yellow-800">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className={`p-2 rounded-full bg-gradient-to-r ${getCategoryColor(achievement.category)} text-white shadow-lg`}>
                            <span className="text-lg">{achievement.icon}</span>
                          </div>
                          <div>
                            <h4 className="font-medium flex items-center">
                              {achievement.title}
                              <CheckCircle className="h-4 w-4 ml-2 text-green-600" />
                            </h4>
                            <p className="text-sm text-muted-foreground">{achievement.description}</p>
                          </div>
                        </div>
                        <Badge className="bg-yellow-600 text-white">
                          Desbloqueada
                        </Badge>
                      </div>
                    </Card>
                  </motion.div>
                ))
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Dialog de detalhes da conquista */}
      <Dialog open={!!selectedAchievement} onOpenChange={() => setSelectedAchievement(null)}>
        <DialogContent className="max-w-md">
          {selectedAchievement && (
            <DialogHeader className="text-center space-y-4">
              <div className={`mx-auto w-16 h-16 rounded-full bg-gradient-to-r ${getCategoryColor(selectedAchievement.category)} flex items-center justify-center shadow-2xl`}>
                <span className="text-2xl">{selectedAchievement.icon}</span>
              </div>
              <DialogTitle className="text-xl">{selectedAchievement.title}</DialogTitle>
              <DialogDescription className="space-y-4">
                <p>{selectedAchievement.description}</p>
                
                {!selectedAchievement.unlocked && selectedAchievement.progress < selectedAchievement.maxProgress && (
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Progresso</span>
                      <span>{selectedAchievement.progress}/{selectedAchievement.maxProgress}</span>
                    </div>
                    <Progress 
                      value={(selectedAchievement.progress / selectedAchievement.maxProgress) * 100} 
                      className="h-3"
                    />
                  </div>
                )}

                <div className="bg-muted rounded-lg p-3 space-y-2">
                  <h4 className="font-medium text-sm">Recompensas:</h4>
                  <div className="flex justify-center space-x-6">
                    <div className="text-center">
                      <div className="text-lg font-bold text-yellow-600">+{selectedAchievement.reward.coins}</div>
                      <div className="text-xs text-muted-foreground">Moedas</div>
                    </div>
                    <div className="text-center">
                      <div className="text-lg font-bold text-purple-600">+{selectedAchievement.reward.xp}</div>
                      <div className="text-xs text-muted-foreground">XP</div>
                    </div>
                  </div>
                </div>

                {selectedAchievement.progress >= selectedAchievement.maxProgress && !selectedAchievement.unlocked && (
                  <Button 
                    onClick={() => handleClaimReward(selectedAchievement)}
                    className="w-full bg-green-600 hover:bg-green-700 text-white"
                  >
                    <Gift className="h-4 w-4 mr-2" />
                    Coletar Recompensa
                  </Button>
                )}
              </DialogDescription>
            </DialogHeader>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}