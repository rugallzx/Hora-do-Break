import React, { useState, useEffect } from 'react';
import { PrivacyTerms } from './PrivacyTerms';
import { AuthScreen } from './AuthScreen';

interface AuthUser {
  id: string;
  email: string;
  name: string;
}

interface WelcomeFlowProps {
  onComplete: (user: AuthUser | null) => void;
}

export function WelcomeFlow({ onComplete }: WelcomeFlowProps) {
  const [currentStep, setCurrentStep] = useState<'privacy' | 'auth' | 'complete'>('privacy');
  const [hasAcceptedTerms, setHasAcceptedTerms] = useState(false);

  // Verificar se o usuário já aceitou os termos anteriormente
  useEffect(() => {
    const acceptedTerms = localStorage.getItem('privacyTermsAccepted');
    const savedUser = localStorage.getItem('authUser');
    
    if (acceptedTerms === 'true') {
      setHasAcceptedTerms(true);
      if (savedUser) {
        // Usuário já está logado
        try {
          const user = JSON.parse(savedUser);
          onComplete(user);
          return;
        } catch (error) {
          console.error('Error parsing saved user:', error);
          localStorage.removeItem('authUser');
        }
      }
      setCurrentStep('auth');
    }
  }, [onComplete]);

  const handleAcceptTerms = () => {
    setHasAcceptedTerms(true);
    localStorage.setItem('privacyTermsAccepted', 'true');
    localStorage.setItem('privacyTermsAcceptedDate', new Date().toISOString());
    setCurrentStep('auth');
  };

  const handleDeclineTerms = () => {
    // Mostrar uma mensagem clara sobre a necessidade dos termos
    alert(
      '⚠️ Não é possível continuar sem aceitar os termos\n\n' +
      'Os termos de privacidade são obrigatórios para:\n' +
      '• Proteger seus dados pessoais\n' +
      '• Garantir transparência sobre o uso das informações\n' +
      '• Oferecer uma experiência segura e confiável\n\n' +
      'Por favor, revise os termos e aceite para continuar usando o aplicativo.'
    );
    // Mantém o modal aberto para que o usuário possa revisar e aceitar
  };

  const handleAuthSuccess = (user: AuthUser) => {
    // Dar bônus de boas-vindas para novos usuários
    const existingData = localStorage.getItem('screenTimeApp');
    if (!existingData) {
      // Usuário novo - adicionar bônus
      const welcomeBonus = {
        dailyScreenTime: 0,
        coins: 250, // Bônus de 50 moedas + 200 iniciais
        level: 1,
        xp: 25, // Bônus de 25 XP
        avatarConfig: { body: 'happy', eyes: 'normal', accessory: 'none' },
        lastBreakTime: Date.now(),
        sessionStartTime: Date.now(),
        weeklyData: [],
        completedMissions: []
      };
      localStorage.setItem('screenTimeApp', JSON.stringify(welcomeBonus));
    }
    
    onComplete(user);
  };

  const handleSkipAuth = () => {
    onComplete(null);
  };

  if (currentStep === 'privacy') {
    return (
      <PrivacyTerms
        isOpen={true}
        onAccept={handleAcceptTerms}
        onDecline={handleDeclineTerms}
      />
    );
  }

  if (currentStep === 'auth') {
    return (
      <AuthScreen
        onAuthSuccess={handleAuthSuccess}
        onSkip={handleSkipAuth}
      />
    );
  }

  return null;
}