import React, { useState, useEffect } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { toast } from 'sonner@2.0.3';
import { projectId, publicAnonKey } from '../utils/supabase/info';
import { User, Cloud, CloudOff, RefreshCw, LogIn, LogOut, UserPlus } from 'lucide-react';

interface AuthUser {
  id: string;
  email: string;
  name: string;
}

interface AuthManagerProps {
  userData: any;
  onUserDataUpdate: (data: any) => void;
  onAuthStateChange: (isAuthenticated: boolean, user: AuthUser | null) => void;
}

export function AuthManager({ userData, onUserDataUpdate, onAuthStateChange }: AuthManagerProps) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState<AuthUser | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [showAuthDialog, setShowAuthDialog] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [lastSync, setLastSync] = useState<Date | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);

  // Form states
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');

  useEffect(() => {
    checkExistingSession();
  }, []);

  const checkExistingSession = async () => {
    const accessToken = localStorage.getItem('supabase_access_token');
    const userData = localStorage.getItem('supabase_user_data');

    if (accessToken && userData) {
      try {
        const parsedUser = JSON.parse(userData);
        setUser(parsedUser);
        setIsAuthenticated(true);
        onAuthStateChange(true, parsedUser);
        
        // Sync data on app start
        await syncData('download');
      } catch (error) {
        console.error('Error parsing stored user data:', error);
        clearSession();
      }
    }
  };

  const clearSession = () => {
    localStorage.removeItem('supabase_access_token');
    localStorage.removeItem('supabase_user_data');
    // Limpar também os dados do novo sistema de auth
    localStorage.removeItem('authUser');
    localStorage.removeItem('authToken');
    setUser(null);
    setIsAuthenticated(false);
    onAuthStateChange(false, null);
  };

  const signup = async () => {
    if (!email || !password || !name) {
      toast.error('Preencha todos os campos');
      return;
    }

    setIsLoading(true);
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-187b714d/auth/signup`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`
        },
        body: JSON.stringify({ email, password, name })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Erro ao criar conta');
      }

      toast.success('Conta criada com sucesso! Fazendo login...');
      
      // Auto login after signup
      await login();

    } catch (error: any) {
      console.error('Signup error:', error);
      toast.error(error.message || 'Erro ao criar conta');
    } finally {
      setIsLoading(false);
    }
  };

  const login = async () => {
    if (!email || !password) {
      toast.error('Preencha email e senha');
      return;
    }

    setIsLoading(true);
    try {
      // Create Supabase client for authentication
      const { createClient } = await import('@supabase/supabase-js');
      const supabase = createClient(
        `https://${projectId}.supabase.co`,
        publicAnonKey
      );

      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password
      });

      if (error) throw error;

      if (data.session?.access_token && data.user) {
        const userData: AuthUser = {
          id: data.user.id,
          email: data.user.email!,
          name: data.user.user_metadata?.name || 'Usuário'
        };

        // Store session data
        localStorage.setItem('supabase_access_token', data.session.access_token);
        localStorage.setItem('supabase_user_data', JSON.stringify(userData));

        setUser(userData);
        setIsAuthenticated(true);
        onAuthStateChange(true, userData);
        setShowAuthDialog(false);

        // Clear form
        setEmail('');
        setPassword('');
        setName('');

        toast.success(`Bem-vindo, ${userData.name}!`);

        // Sync data after login
        await syncData('merge');
      }

    } catch (error: any) {
      console.error('Login error:', error);
      toast.error(error.message || 'Erro ao fazer login');
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    try {
      // Upload local data before logout
      if (userData) {
        await syncData('upload');
      }

      // Create Supabase client for logout
      const { createClient } = await import('@supabase/supabase-js');
      const supabase = createClient(
        `https://${projectId}.supabase.co`,
        publicAnonKey
      );

      await supabase.auth.signOut();
      
      clearSession();
      toast.success('Logout realizado com sucesso');

    } catch (error: any) {
      console.error('Logout error:', error);
      clearSession(); // Force logout even if there's an error
      toast.error('Erro ao fazer logout, mas sessão foi encerrada');
    }
  };

  const syncData = async (action: 'upload' | 'download' | 'merge') => {
    if (!isAuthenticated || !user) {
      toast.error('Faça login para sincronizar dados');
      return;
    }

    setIsSyncing(true);
    try {
      const accessToken = localStorage.getItem('supabase_access_token');
      
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-187b714d/sync`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`
        },
        body: JSON.stringify({
          userData,
          action
        })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Erro ao sincronizar dados');
      }

      if (data.userData && (action === 'download' || action === 'merge')) {
        onUserDataUpdate(data.userData);
      }

      setLastSync(new Date());
      toast.success(data.message || 'Dados sincronizados com sucesso');

    } catch (error: any) {
      console.error('Sync error:', error);
      toast.error(error.message || 'Erro ao sincronizar dados');
    } finally {
      setIsSyncing(false);
    }
  };

  // Auto-sync every 30 minutes when authenticated
  useEffect(() => {
    if (isAuthenticated) {
      const interval = setInterval(() => {
        syncData('merge');
      }, 30 * 60 * 1000);

      return () => clearInterval(interval);
    }
  }, [isAuthenticated, userData]);

  return (
    <div className="space-y-4">
      {/* Status Card */}
      <Card className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className={`p-2 rounded-full ${isAuthenticated ? 'bg-green-100' : 'bg-gray-100'}`}>
              {isAuthenticated ? (
                <User className="h-4 w-4 text-green-600" />
              ) : (
                <User className="h-4 w-4 text-gray-600" />
              )}
            </div>
            <div>
              <p className="font-medium">
                {isAuthenticated ? user?.name : 'Não autenticado'}
              </p>
              <p className="text-sm text-muted-foreground">
                {isAuthenticated ? user?.email : 'Faça login para sincronizar dados'}
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            {isAuthenticated && (
              <div className="flex items-center space-x-1">
                {isSyncing ? (
                  <CloudOff className="h-4 w-4 text-yellow-500" />
                ) : (
                  <Cloud className="h-4 w-4 text-green-500" />
                )}
                <Badge variant={isSyncing ? 'secondary' : 'default'}>
                  {isSyncing ? 'Sincronizando...' : 'Sincronizado'}
                </Badge>
              </div>
            )}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-2 mt-4">
          {!isAuthenticated ? (
            <Button onClick={() => setShowAuthDialog(true)} className="flex-1">
              <LogIn className="h-4 w-4 mr-2" />
              Entrar / Cadastrar
            </Button>
          ) : (
            <>
              <Button 
                onClick={() => syncData('merge')} 
                disabled={isSyncing}
                variant="outline"
                className="flex-1"
              >
                {isSyncing ? (
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <RefreshCw className="h-4 w-4 mr-2" />
                )}
                Sincronizar
              </Button>
              <Button onClick={logout} variant="outline">
                <LogOut className="h-4 w-4 mr-2" />
                Sair
              </Button>
            </>
          )}
        </div>

        {lastSync && (
          <p className="text-xs text-muted-foreground mt-2 text-center">
            Última sincronização: {lastSync.toLocaleString()}
          </p>
        )}
      </Card>

      {/* Auth Dialog */}
      <Dialog open={showAuthDialog} onOpenChange={setShowAuthDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {authMode === 'login' ? 'Entrar na Conta' : 'Criar Conta'}
            </DialogTitle>
            <DialogDescription>
              {authMode === 'login' 
                ? 'Entre com sua conta para sincronizar dados entre dispositivos'
                : 'Crie uma conta para salvar seus dados na nuvem'
              }
            </DialogDescription>
          </DialogHeader>

          <Tabs value={authMode} onValueChange={(v) => setAuthMode(v as any)}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="login">Entrar</TabsTrigger>
              <TabsTrigger value="signup">Cadastrar</TabsTrigger>
            </TabsList>

            <TabsContent value="login" className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="seu@email.com"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Senha</Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Sua senha"
                />
              </div>
              <Button onClick={login} disabled={isLoading} className="w-full">
                {isLoading && <RefreshCw className="h-4 w-4 mr-2 animate-spin" />}
                Entrar
              </Button>
            </TabsContent>

            <TabsContent value="signup" className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label htmlFor="name">Nome</Label>
                <Input
                  id="name"
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Seu nome"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="seu@email.com"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Senha</Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Crie uma senha"
                />
              </div>
              <Button onClick={signup} disabled={isLoading} className="w-full">
                {isLoading && <RefreshCw className="h-4 w-4 mr-2 animate-spin" />}
                <UserPlus className="h-4 w-4 mr-2" />
                Criar Conta
              </Button>
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>

      {/* Benefits Card */}
      <Card className="p-4 bg-blue-50 border-blue-200">
        <h4 className="font-medium text-blue-800 mb-2">
          Benefícios da Sincronização
        </h4>
        <ul className="text-sm text-blue-700 space-y-1">
          <li>• Acesse seus dados em qualquer dispositivo</li>
          <li>• Backup automático de progresso e conquistas</li>
          <li>• Sincronização em tempo real entre dispositivos</li>
          <li>• Relatórios consolidados de múltiplos dispositivos</li>
          <li>• Nunca perca seu progresso novamente</li>
        </ul>
      </Card>
    </div>
  );
}