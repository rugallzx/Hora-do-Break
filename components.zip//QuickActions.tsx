import React from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { 
  Coffee, 
  Eye, 
  Smartphone, 
  Target, 
  Timer, 
  Lightbulb,
  Activity,
  Moon,
  Sun
} from 'lucide-react';

interface QuickActionsProps {
  onTakeBreak: () => void;
  onStartFocusMode: () => void;
  onSetGoal: () => void;
  currentEnergy: number;
  isBreakTime: boolean;
}

export function QuickActions({ 
  onTakeBreak, 
  onStartFocusMode, 
  onSetGoal, 
  currentEnergy,
  isBreakTime 
}: QuickActionsProps) {
  const quickBreakActivities = [
    { icon: Eye, name: '👁️ Exercício Visual', desc: '2 min', action: () => {} },
    { icon: Coffee, name: '☕ Hidratação', desc: '1 min', action: () => {} },
    { icon: Activity, name: '🤸 Alongamento', desc: '3 min', action: () => {} },
    { icon: Moon, name: '🧘 Respiração', desc: '2 min', action: () => {} }
  ];

  const focusModes = [
    { name: '📚 Estudo', time: '25 min', color: 'from-blue-500 to-blue-600' },
    { name: '💼 Trabalho', time: '50 min', color: 'from-green-500 to-green-600' },
    { name: '🎨 Criativo', time: '30 min', color: 'from-purple-500 to-purple-600' },
    { name: '📖 Leitura', time: '20 min', color: 'from-orange-500 to-orange-600' }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {/* Quick Break Actions */}
      <Card className="p-6 bg-gradient-to-br from-green-50 to-emerald-50 border-l-4 border-l-green-400">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-green-800 flex items-center space-x-2">
            <Coffee className="h-5 w-5" />
            <span>Pausas Rápidas</span>
          </h3>
          <Badge 
            className={`${currentEnergy > 70 ? 'bg-green-500' : currentEnergy > 40 ? 'bg-yellow-500' : 'bg-red-500'} text-white`}
          >
            Energia: {currentEnergy}%
          </Badge>
        </div>
        
        <div className="space-y-3">
          <Button 
            onClick={onTakeBreak}
            className={`w-full justify-start ${
              isBreakTime 
                ? 'bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 animate-pulse' 
                : 'bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700'
            }`}
            size="sm"
          >
            <Timer className="h-4 w-4 mr-2" />
            {isBreakTime ? 'Pausa Recomendada Agora!' : 'Fazer Pausa (5 min)'}
          </Button>

          <div className="grid grid-cols-2 gap-2">
            {quickBreakActivities.map((activity, index) => (
              <Button
                key={index}
                variant="outline"
                size="sm"
                className="h-auto p-2 flex flex-col items-start text-left hover:bg-green-100 border-green-200"
                onClick={activity.action}
              >
                <div className="flex items-center space-x-1 w-full">
                  <activity.icon className="h-3 w-3" />
                  <span className="text-xs font-medium truncate">{activity.name}</span>
                </div>
                <span className="text-xs text-muted-foreground">{activity.desc}</span>
              </Button>
            ))}
          </div>
        </div>
      </Card>

      {/* Focus Mode & Goals */}
      <Card className="p-6 bg-gradient-to-br from-blue-50 to-indigo-50 border-l-4 border-l-blue-400">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-blue-800 flex items-center space-x-2">
            <Target className="h-5 w-5" />
            <span>Foco & Metas</span>
          </h3>
        </div>
        
        <div className="space-y-3">
          <Button 
            onClick={onSetGoal}
            variant="outline"
            className="w-full justify-start border-blue-300 hover:bg-blue-100"
            size="sm"
          >
            <Lightbulb className="h-4 w-4 mr-2" />
            Definir Meta Diária
          </Button>

          <div className="space-y-2">
            <p className="text-xs text-blue-700 font-medium mb-2">🎯 Modos de Foco:</p>
            <div className="grid grid-cols-1 gap-1">
              {focusModes.map((mode, index) => (
                <Button
                  key={index}
                  variant="outline"
                  size="sm"
                  className="h-auto p-2 justify-between hover:bg-blue-100 border-blue-200"
                  onClick={onStartFocusMode}
                >
                  <div className="flex items-center">
                    <span className="text-xs font-medium">{mode.name}</span>
                  </div>
                  <span className="text-xs text-muted-foreground">{mode.time}</span>
                </Button>
              ))}
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}