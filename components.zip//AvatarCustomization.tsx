import React, { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { toast } from 'sonner@2.0.3';
import { Avatar } from './Avatar';
import { Palette, Eye, Crown, Shirt, Coins, Scissors } from 'lucide-react';

interface CustomizationItem {
  id: string;
  name: string;
  cost: number;
  category: 'body' | 'eyes' | 'accessory' | 'hair';
  value: string;
  description: string;
  unlocked: boolean;
}

interface AvatarCustomizationProps {
  userData: any;
  onSpendCoins: (amount: number) => boolean;
  onUpdateAvatar: (config: any) => void;
  currentEnergy: number;
}

export function AvatarCustomization({ userData, onSpendCoins, onUpdateAvatar, currentEnergy }: AvatarCustomizationProps) {
  const [previewConfig, setPreviewConfig] = useState(userData.avatarConfig);

  // Atualizar preview quando userData.avatarConfig muda
  React.useEffect(() => {
    setPreviewConfig(userData.avatarConfig);
  }, [userData.avatarConfig]);

  const customizationItems: CustomizationItem[] = [
    // Cores do Corpo
    {
      id: 'body_happy',
      name: 'Azul Alegre',
      cost: 0,
      category: 'body',
      value: 'happy',
      description: 'A cor padrão do seu avatar',
      unlocked: true
    },
    {
      id: 'body_energetic',
      name: 'Verde Energético',
      cost: 50,
      category: 'body',
      value: 'energetic',
      description: 'Para quando você está cheio de energia!',
      unlocked: userData.coins >= 50 || userData.avatarConfig.body === 'energetic'
    },
    {
      id: 'body_calm',
      name: 'Roxo Calmo',
      cost: 75,
      category: 'body',
      value: 'calm',
      description: 'Perfeito para momentos zen',
      unlocked: userData.coins >= 75 || userData.avatarConfig.body === 'calm'
    },
    {
      id: 'body_fire',
      name: 'Vermelho Fogo',
      cost: 100,
      category: 'body',
      value: 'fire',
      description: 'Para os mais determinados',
      unlocked: userData.coins >= 100 || userData.avatarConfig.body === 'fire'
    },
    {
      id: 'body_pink',
      name: 'Rosa Doce',
      cost: 60,
      category: 'body',
      value: 'pink',
      description: 'Suave e carinhoso',
      unlocked: userData.coins >= 60 || userData.avatarConfig.body === 'pink'
    },
    {
      id: 'body_orange',
      name: 'Laranja Vibrante',
      cost: 80,
      category: 'body',
      value: 'orange',
      description: 'Criativo e otimista',
      unlocked: userData.coins >= 80 || userData.avatarConfig.body === 'orange'
    },
    {
      id: 'body_cyan',
      name: 'Ciano Refrescante',
      cost: 90,
      category: 'body',
      value: 'cyan',
      description: 'Fresco como uma brisa',
      unlocked: userData.coins >= 90 || userData.avatarConfig.body === 'cyan'
    },
    {
      id: 'body_brown',
      name: 'Marrom Natural',
      cost: 70,
      category: 'body',
      value: 'brown',
      description: 'Conectado com a natureza',
      unlocked: userData.coins >= 70 || userData.avatarConfig.body === 'brown'
    },
    {
      id: 'body_gold',
      name: 'Dourado Premium',
      cost: 200,
      category: 'body',
      value: 'gold',
      description: 'Para os verdadeiros VIPs',
      unlocked: userData.coins >= 200 || userData.avatarConfig.body === 'gold'
    },
    {
      id: 'body_rainbow',
      name: 'Arco-Íris Mágico',
      cost: 300,
      category: 'body',
      value: 'rainbow',
      description: 'Todas as cores em harmonia',
      unlocked: userData.coins >= 300 || userData.avatarConfig.body === 'rainbow'
    },

    // Olhos
    {
      id: 'eyes_normal',
      name: 'Olhos Normais',
      cost: 0,
      category: 'eyes',
      value: 'normal',
      description: 'Os olhos padrão',
      unlocked: true
    },
    {
      id: 'eyes_sleepy',
      name: 'Olhos Sonolentos',
      cost: 30,
      category: 'eyes',
      value: 'sleepy',
      description: 'Para quando está cansado',
      unlocked: userData.coins >= 30 || userData.avatarConfig.eyes === 'sleepy'
    },
    {
      id: 'eyes_excited',
      name: 'Olhos Empolgados',
      cost: 40,
      category: 'eyes',
      value: 'excited',
      description: 'Cheio de energia!',
      unlocked: userData.coins >= 40 || userData.avatarConfig.eyes === 'excited'
    },
    {
      id: 'eyes_wink',
      name: 'Olhos Piscando',
      cost: 50,
      category: 'eyes',
      value: 'wink',
      description: 'Um charme especial',
      unlocked: userData.coins >= 50 || userData.avatarConfig.eyes === 'wink'
    },
    {
      id: 'eyes_heart',
      name: 'Olhos Coração',
      cost: 70,
      category: 'eyes',
      value: 'heart',
      description: 'Apaixonado pela vida',
      unlocked: userData.coins >= 70 || userData.avatarConfig.eyes === 'heart'
    },
    {
      id: 'eyes_star',
      name: 'Olhos Estrelados',
      cost: 80,
      category: 'eyes',
      value: 'star',
      description: 'Para os verdadeiros campeões',
      unlocked: userData.coins >= 80 || userData.avatarConfig.eyes === 'star'
    },
    {
      id: 'eyes_diamond',
      name: 'Olhos Diamante',
      cost: 120,
      category: 'eyes',
      value: 'diamond',
      description: 'Brilha como uma joia',
      unlocked: userData.coins >= 120 || userData.avatarConfig.eyes === 'diamond'
    },
    {
      id: 'eyes_robot',
      name: 'Olhos Robóticos',
      cost: 150,
      category: 'eyes',
      value: 'robot',
      description: 'Do futuro para você',
      unlocked: userData.coins >= 150 || userData.avatarConfig.eyes === 'robot'
    },
    {
      id: 'eyes_angry',
      name: 'Olhos Determinados',
      cost: 100,
      category: 'eyes',
      value: 'angry',
      description: 'Focado nos objetivos',
      unlocked: userData.coins >= 100 || userData.avatarConfig.eyes === 'angry'
    },

    // Acessórios
    {
      id: 'accessory_none',
      name: 'Sem Acessório',
      cost: 0,
      category: 'accessory',
      value: 'none',
      description: 'Visual clean e natural',
      unlocked: true
    },
    {
      id: 'accessory_glasses',
      name: 'Óculos Clássicos',
      cost: 40,
      category: 'accessory',
      value: 'glasses',
      description: 'Para os intelectuais e estudiosos',
      unlocked: userData.coins >= 40 || userData.avatarConfig.accessory === 'glasses'
    },
    {
      id: 'accessory_hat',
      name: 'Chapéu Vermelho',
      cost: 60,
      category: 'accessory',
      value: 'hat',
      description: 'Estilo clássico e elegante',
      unlocked: userData.coins >= 60 || userData.avatarConfig.accessory === 'hat'
    },
    {
      id: 'accessory_bandana',
      name: 'Bandana Vermelha',
      cost: 85,
      category: 'accessory',
      value: 'bandana',
      description: 'Estilo urbano e moderno',
      unlocked: userData.coins >= 85 || userData.avatarConfig.accessory === 'bandana'
    },
    {
      id: 'accessory_chain',
      name: 'Corrente de Ouro',
      cost: 100,
      category: 'accessory',
      value: 'chain',
      description: 'Para os verdadeiros conquistadores digitais',
      unlocked: userData.coins >= 100 || userData.avatarConfig.accessory === 'chain'
    },
    {
      id: 'accessory_crown',
      name: 'Coroa Real',
      cost: 150,
      category: 'accessory',
      value: 'crown',
      description: 'Para a realeza digital suprema',
      unlocked: userData.coins >= 150 || userData.avatarConfig.accessory === 'crown'
    },

    // Cabelos
    {
      id: 'hair_none',
      name: 'Sem Cabelo',
      cost: 0,
      category: 'hair',
      value: 'none',
      description: 'Visual careca e clean',
      unlocked: true
    },
    {
      id: 'hair_short',
      name: 'Cabelo Curto Marrom',
      cost: 30,
      category: 'hair',
      value: 'short',
      description: 'Estilo clássico e bem cuidado',
      unlocked: userData.coins >= 30 || userData.avatarConfig.hair === 'short'
    },
    {
      id: 'hair_long',
      name: 'Cabelo Longo Marrom',
      cost: 50,
      category: 'hair',
      value: 'long',
      description: 'Elegante com mechas laterais',
      unlocked: userData.coins >= 50 || userData.avatarConfig.hair === 'long'
    },
    {
      id: 'hair_curly',
      name: 'Cabelo Cacheado Marrom',
      cost: 70,
      category: 'hair',
      value: 'curly',
      description: 'Cachos naturais e estilosos',
      unlocked: userData.coins >= 70 || userData.avatarConfig.hair === 'curly'
    },
    {
      id: 'hair_spiky',
      name: 'Cabelo Espetado Marrom',
      cost: 80,
      category: 'hair',
      value: 'spiky',
      description: 'Pontas arrepiadas e modernas',
      unlocked: userData.coins >= 80 || userData.avatarConfig.hair === 'spiky'
    },
    {
      id: 'hair_mohawk',
      name: 'Moicano Marrom',
      cost: 100,
      category: 'hair',
      value: 'mohawk',
      description: 'Estilo central marcante',
      unlocked: userData.coins >= 100 || userData.avatarConfig.hair === 'mohawk'
    },
    {
      id: 'hair_ponytail',
      name: 'Rabo de Cavalo Marrom',
      cost: 60,
      category: 'hair',
      value: 'ponytail',
      description: 'Prático com rabinho lateral',
      unlocked: userData.coins >= 60 || userData.avatarConfig.hair === 'ponytail'
    }
  ];

  const purchaseItem = (item: CustomizationItem) => {
    if (item.cost === 0 || onSpendCoins(item.cost)) {
      let newConfig = { ...userData.avatarConfig, [item.category]: item.value };
      
      // Se for cabelo e não for 'none', remover acessórios de cabeça
      if (item.category === 'hair' && item.value !== 'none') {
        const headAccessories = ['hat', 'bandana', 'crown'];
        if (headAccessories.includes(newConfig.accessory)) {
          newConfig.accessory = 'none';
          toast.info('Acessório de cabeça removido automaticamente');
        }
      }
      
      onUpdateAvatar(newConfig);
      setPreviewConfig(newConfig);
      toast.success(`${item.name} comprado com sucesso!`);
    } else {
      toast.error('Moedas insuficientes!');
    }
  };

  const equipItem = (item: CustomizationItem) => {
    let newConfig = { ...userData.avatarConfig, [item.category]: item.value };
    
    // Se for cabelo e não for 'none', remover acessórios de cabeça
    if (item.category === 'hair' && item.value !== 'none') {
      const headAccessories = ['hat', 'bandana', 'crown'];
      if (headAccessories.includes(newConfig.accessory)) {
        newConfig.accessory = 'none';
        toast.info('Acessório de cabeça removido automaticamente');
      }
    }
    
    onUpdateAvatar(newConfig);
    setPreviewConfig(newConfig);
    toast.success(`${item.name} equipado!`);
  };

  const renderCustomizationGrid = (category: 'body' | 'eyes' | 'accessory' | 'hair') => {
    const items = customizationItems.filter(item => item.category === category);
    
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {items.map(item => {
          const isOwned = userData.avatarConfig[category] === item.value;
          const isSelected = previewConfig[category] === item.value;
          const canAfford = userData.coins >= item.cost;
          
          // Verificar se é acessório de cabeça e se há cabelo selecionado
          const isHeadAccessory = category === 'accessory' && ['hat', 'bandana', 'crown'].includes(item.value);
          const hasHair = previewConfig.hair && previewConfig.hair !== 'none';
          const isBlocked = isHeadAccessory && hasHair;

          return (
            <Card 
              key={item.id} 
              className={`p-4 cursor-pointer transition-all hover:shadow-md ${
                isSelected ? 'ring-2 ring-blue-500 bg-blue-50' : ''
              } ${(!item.unlocked || isBlocked) ? 'opacity-50' : ''}`}
              onClick={() => {
                if (item.unlocked && !isBlocked) {
                  setPreviewConfig(prev => {
                    let newConfig = { ...prev, [category]: item.value };
                    
                    // Se for cabelo e não for 'none', remover acessórios de cabeça no preview
                    if (category === 'hair' && item.value !== 'none') {
                      const headAccessories = ['hat', 'bandana', 'crown'];
                      if (headAccessories.includes(newConfig.accessory)) {
                        newConfig.accessory = 'none';
                      }
                    }
                    
                    return newConfig;
                  });
                }
              }}
            >
              <div className="flex justify-between items-start mb-2">
                <div>
                  <h4 className="font-medium">{item.name}</h4>
                  <p className="text-sm text-muted-foreground">
                    {isBlocked ? 'Não é possível usar com cabelo' : item.description}
                  </p>
                </div>
                {isBlocked ? (
                  <Badge variant="destructive">Bloqueado</Badge>
                ) : isOwned ? (
                  <Badge variant="default">Possui</Badge>
                ) : (
                  <Badge variant={canAfford ? 'secondary' : 'destructive'}>
                    <Coins className="h-3 w-3 mr-1" />
                    {item.cost}
                  </Badge>
                )}
              </div>

              {isBlocked ? (
                <Button size="sm" className="w-full" disabled>
                  Remova o cabelo primeiro
                </Button>
              ) : !isOwned && item.unlocked ? (
                <Button 
                  size="sm" 
                  className="w-full"
                  disabled={!canAfford}
                  onClick={(e) => {
                    e.stopPropagation();
                    purchaseItem(item);
                  }}
                >
                  {canAfford ? 'Comprar' : 'Moedas Insuficientes'}
                </Button>
              ) : !item.unlocked ? (
                <Button size="sm" className="w-full" disabled>
                  Bloqueado
                </Button>
              ) : isOwned ? (
                <Button 
                  size="sm" 
                  variant="outline" 
                  className="w-full"
                  onClick={(e) => {
                    e.stopPropagation();
                    equipItem(item);
                  }}
                >
                  Equipar
                </Button>
              ) : null}
            </Card>
          );
        })}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2>Personalização do Avatar</h2>
        <p className="text-muted-foreground">
          Use suas moedas para personalizar seu avatar!
        </p>
        <Badge variant="outline" className="mt-2">
          <Coins className="h-4 w-4 mr-1" />
          {userData.coins} moedas disponíveis
        </Badge>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Preview do Avatar */}
        <Card className="p-6">
          <h3 className="mb-4 text-center">Preview</h3>
          <Avatar 
            config={previewConfig}
            energy={currentEnergy} // Energia atual sincronizada
            screenTime={userData.dailyScreenTime}
          />
          <div className="mt-4 text-center space-y-2">
            <Button 
              onClick={() => {
                onUpdateAvatar(previewConfig);
                toast.success('Avatar atualizado!');
              }}
              disabled={JSON.stringify(previewConfig) === JSON.stringify(userData.avatarConfig)}
            >
              Aplicar Mudanças
            </Button>
            <Button 
              variant="outline"
              onClick={() => setPreviewConfig(userData.avatarConfig)}
            >
              Resetar Preview
            </Button>
          </div>
        </Card>

        {/* Opções de Personalização */}
        <Card className="p-6">
          <Tabs defaultValue="body">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="body" className="flex items-center space-x-1">
                <Shirt className="h-4 w-4" />
                <span>Corpo</span>
              </TabsTrigger>
              <TabsTrigger value="eyes" className="flex items-center space-x-1">
                <Eye className="h-4 w-4" />
                <span>Olhos</span>
              </TabsTrigger>
              <TabsTrigger value="hair" className="flex items-center space-x-1">
                <Scissors className="h-4 w-4" />
                <span>Cabelos</span>
              </TabsTrigger>
              <TabsTrigger value="accessory" className="flex items-center space-x-1">
                <Crown className="h-4 w-4" />
                <span>Acessórios</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="body" className="mt-4">
              {renderCustomizationGrid('body')}
            </TabsContent>

            <TabsContent value="eyes" className="mt-4">
              {renderCustomizationGrid('eyes')}
            </TabsContent>

            <TabsContent value="hair" className="mt-4">
              {renderCustomizationGrid('hair')}
            </TabsContent>

            <TabsContent value="accessory" className="mt-4">
              {renderCustomizationGrid('accessory')}
            </TabsContent>
          </Tabs>
        </Card>
      </div>

      {/* Dicas de Economia */}
      <Card className="p-4 bg-yellow-50 border-yellow-200">
        <h4 className="flex items-center space-x-2 mb-2">
          <Palette className="h-4 w-4 text-yellow-600" />
          <span>Dicas para Ganhar Moedas</span>
        </h4>
        <ul className="text-sm text-muted-foreground space-y-1">
          <li>• Complete missões diárias para ganhar moedas regulares</li>
          <li>• Faça pausas quando solicitado (+10 moedas)</li>
          <li>• Mantenha seu tempo de tela baixo para bônus extras</li>
          <li>• Conquistas especiais dão grandes recompensas!</li>
        </ul>
      </Card>

      {/* Regras de Compatibilidade */}
      <Card className="p-4 bg-blue-50 border-blue-200">
        <h4 className="flex items-center space-x-2 mb-2">
          <Crown className="h-4 w-4 text-blue-600" />
          <span>Regras de Compatibilidade</span>
        </h4>
        <div className="text-sm text-muted-foreground space-y-1">
          <p>⚠️ <strong>Cabelos e acessórios de cabeça não podem ser usados juntos:</strong></p>
          <ul className="ml-4 space-y-1">
            <li>• Chapéu, Bandana e Coroa são acessórios de cabeça</li>
            <li>• Ao escolher um cabelo, acessórios de cabeça serão removidos automaticamente</li>
            <li>• Óculos e Corrente podem ser usados com qualquer cabelo</li>
            <li>• Para usar acessórios de cabeça, escolha "Sem Cabelo" primeiro</li>
          </ul>
        </div>
      </Card>

      {/* Coleção de Estilos */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Cabelos */}
        <Card className="p-4 bg-gradient-to-r from-amber-50 to-orange-50 border-amber-200">
          <h4 className="flex items-center space-x-2 mb-3">
            <Scissors className="h-4 w-4 text-amber-600" />
            <span>Estilos de Cabelo</span>
          </h4>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div className="text-center p-2 bg-white/60 rounded-lg border">
              <div className="text-lg mb-1">✂️</div>
              <div className="font-medium">Curto</div>
              <div className="text-xs text-muted-foreground">Clássico</div>
            </div>
            <div className="text-center p-2 bg-white/60 rounded-lg border">
              <div className="text-lg mb-1">💇</div>
              <div className="font-medium">Longo</div>
              <div className="text-xs text-muted-foreground">Elegante</div>
            </div>
            <div className="text-center p-2 bg-white/60 rounded-lg border">
              <div className="text-lg mb-1">🌀</div>
              <div className="font-medium">Cacheado</div>
              <div className="text-xs text-muted-foreground">Estiloso</div>
            </div>
            <div className="text-center p-2 bg-white/60 rounded-lg border">
              <div className="text-lg mb-1">⚡</div>
              <div className="font-medium">Espetado</div>
              <div className="text-xs text-muted-foreground">Radical</div>
            </div>
          </div>
        </Card>

        {/* Acessórios */}
        <Card className="p-4 bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200">
          <h4 className="flex items-center space-x-2 mb-3">
            <Crown className="h-4 w-4 text-purple-600" />
            <span>Acessórios Premium</span>
          </h4>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div className="text-center p-2 bg-white/60 rounded-lg border">
              <div className="text-lg mb-1">👓</div>
              <div className="font-medium">Óculos</div>
              <div className="text-xs text-muted-foreground">Intelectual</div>
            </div>
            <div className="text-center p-2 bg-white/60 rounded-lg border">
              <div className="text-lg mb-1">🔴</div>
              <div className="font-medium">Bandana</div>
              <div className="text-xs text-muted-foreground">Urbano</div>
            </div>
            <div className="text-center p-2 bg-white/60 rounded-lg border">
              <div className="text-lg mb-1">👑</div>
              <div className="font-medium">Coroa</div>
              <div className="text-xs text-muted-foreground">Realeza</div>
            </div>
            <div className="text-center p-2 bg-white/60 rounded-lg border">
              <div className="text-lg mb-1">⛓️</div>
              <div className="font-medium">Corrente</div>
              <div className="text-xs text-muted-foreground">Estiloso</div>
            </div>
          </div>
        </Card>
      </div>
      
      <p className="text-xs text-center text-muted-foreground">
        🎯 Cada estilo reflete sua personalidade digital única!
      </p>
    </div>
  );
}