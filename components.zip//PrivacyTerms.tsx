import React from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { ScrollArea } from './ui/scroll-area';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { Badge } from './ui/badge';
import { Shield, Eye, Lock, Database, Smartphone, Users, Coffee } from 'lucide-react';

interface PrivacyTermsProps {
  isOpen: boolean;
  onAccept: () => void;
  onDecline: () => void;
}

export function PrivacyTerms({ isOpen, onAccept, onDecline }: PrivacyTermsProps) {
  return (
    <Dialog open={isOpen} onOpenChange={() => {}} modal>
      <DialogContent 
        className="max-w-2xl max-h-[90vh] bg-gradient-to-br from-blue-50 to-purple-50 border-2 border-blue-200"
        onEscapeKeyDown={(e) => e.preventDefault()}
        onPointerDownOutside={(e) => e.preventDefault()}
        onInteractOutside={(e) => e.preventDefault()}
      >        
        <DialogHeader className="text-center space-y-4">
          <div className="mx-auto w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
            <Coffee className="h-8 w-8 text-white" />
          </div>
          <DialogTitle className="text-2xl bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Bem-vindo ao Hora do Break! ☕
          </DialogTitle>
          <DialogDescription className="text-gray-700">
            Antes de começar sua jornada saudável, precisamos que você conheça nossos termos de privacidade
          </DialogDescription>
        </DialogHeader>

        <ScrollArea className="h-[400px] w-full rounded-md border p-4 bg-white/70">
          <div className="space-y-6">
            {/* Introdução */}
            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <Shield className="h-5 w-5 text-green-600" />
                <h3 className="font-semibold text-green-800">Sua Privacidade é Nossa Prioridade</h3>
              </div>
              <p className="text-sm text-gray-700 leading-relaxed">
                O Hora do Break foi desenvolvido para ajudar você a manter um equilíbrio saudável com a tecnologia. 
                Entendemos que seus dados são pessoais e importantes, por isso criamos esta política simples e transparente.
              </p>
            </div>

            {/* Dados Coletados */}
            <Card className="p-4 bg-blue-50 border-blue-200">
              <div className="flex items-center space-x-2 mb-3">
                <Database className="h-5 w-5 text-blue-600" />
                <h4 className="font-medium text-blue-800">Quais dados coletamos?</h4>
              </div>
              <ul className="space-y-2 text-sm text-blue-700">
                <li className="flex items-start space-x-2">
                  <span className="text-blue-500 mt-1">•</span>
                  <span><strong>Tempo de tela:</strong> Monitoramos apenas para ajudar você a manter hábitos saudáveis</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-blue-500 mt-1">•</span>
                  <span><strong>Progresso do jogo:</strong> Níveis, moedas e customizações do avatar</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-blue-500 mt-1">•</span>
                  <span><strong>Preferências:</strong> Configurações de notificações e metas pessoais</span>
                </li>
              </ul>
            </Card>

            {/* Como usamos */}
            <Card className="p-4 bg-green-50 border-green-200">
              <div className="flex items-center space-x-2 mb-3">
                <Eye className="h-5 w-5 text-green-600" />
                <h4 className="font-medium text-green-800">Como usamos seus dados?</h4>
              </div>
              <ul className="space-y-2 text-sm text-green-700">
                <li className="flex items-start space-x-2">
                  <span className="text-green-500 mt-1">•</span>
                  <span>Gerar relatórios personalizados do seu progresso</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-green-500 mt-1">•</span>
                  <span>Enviar lembretes gentis para pausas saudáveis</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-green-500 mt-1">•</span>
                  <span>Sincronizar seus dados entre dispositivos (opcional)</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-green-500 mt-1">•</span>
                  <span>Melhorar continuamente a experiência do aplicativo</span>
                </li>
              </ul>
            </Card>

            {/* Segurança */}
            <Card className="p-4 bg-purple-50 border-purple-200">
              <div className="flex items-center space-x-2 mb-3">
                <Lock className="h-5 w-5 text-purple-600" />
                <h4 className="font-medium text-purple-800">Como protegemos seus dados?</h4>
              </div>
              <ul className="space-y-2 text-sm text-purple-700">
                <li className="flex items-start space-x-2">
                  <span className="text-purple-500 mt-1">•</span>
                  <span><strong>Criptografia:</strong> Todos os dados são criptografados em trânsito e armazenamento</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-purple-500 mt-1">•</span>
                  <span><strong>Validação:</strong> Sistema anti-burla com verificação de integridade</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-purple-500 mt-1">•</span>
                  <span><strong>Acesso limitado:</strong> Apenas você tem acesso aos seus dados pessoais</span>
                </li>
              </ul>
            </Card>

            {/* Direitos do usuário */}
            <Card className="p-4 bg-orange-50 border-orange-200">
              <div className="flex items-center space-x-2 mb-3">
                <Users className="h-5 w-5 text-orange-600" />
                <h4 className="font-medium text-orange-800">Seus direitos</h4>
              </div>
              <ul className="space-y-2 text-sm text-orange-700">
                <li className="flex items-start space-x-2">
                  <span className="text-orange-500 mt-1">•</span>
                  <span><strong>Exportar:</strong> Baixe todos os seus dados a qualquer momento</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-orange-500 mt-1">•</span>
                  <span><strong>Excluir:</strong> Remova sua conta e dados permanentemente</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-orange-500 mt-1">•</span>
                  <span><strong>Controlar:</strong> Desative recursos de coleta a qualquer momento</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-orange-500 mt-1">•</span>
                  <span><strong>Suporte:</strong> Entre em contato conosco sobre qualquer dúvida</span>
                </li>
              </ul>
            </Card>

            {/* Dispositivos */}
            <Card className="p-4 bg-indigo-50 border-indigo-200">
              <div className="flex items-center space-x-2 mb-3">
                <Smartphone className="h-5 w-5 text-indigo-600" />
                <h4 className="font-medium text-indigo-800">Permissões do Dispositivo</h4>
              </div>
              <ul className="space-y-2 text-sm text-indigo-700">
                <li className="flex items-start space-x-2">
                  <span className="text-indigo-500 mt-1">•</span>
                  <span><strong>Uso de Aplicativos:</strong> Para monitorar tempo de tela (opcional)</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-indigo-500 mt-1">•</span>
                  <span><strong>Notificações:</strong> Para lembretes de pausa personalizados</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-indigo-500 mt-1">•</span>
                  <span><strong>Internet:</strong> Para sincronização opcional entre dispositivos</span>
                </li>
              </ul>
            </Card>

            {/* Importante */}
            <div className="bg-gradient-to-r from-red-50 to-pink-50 border border-red-200 rounded-lg p-4">
              <div className="flex items-center space-x-2 mb-2">
                <span className="text-xl">⚠️</span>
                <h4 className="font-medium text-red-800">Importante: Dados Sensíveis</h4>
              </div>
              <p className="text-sm text-red-700 leading-relaxed">
                O Hora do Break <strong>NÃO</strong> coleta informações pessoais identificáveis (PII) como CPF, RG, 
                dados bancários ou informações de localização precisa. Focamos apenas em dados necessários 
                para uma experiência gamificada e saudável.
              </p>
            </div>

            {/* Contato */}
            <div className="bg-gray-50 rounded-lg p-4 text-center">
              <p className="text-sm text-gray-600">
                Tem dúvidas sobre nossa política? Entre em contato: 
                <br />
                <strong className="text-blue-600">privacidade@horadobreak.app</strong>
              </p>
            </div>
          </div>
        </ScrollArea>

        <div className="flex flex-col space-y-3 mt-4">
          <div className="flex items-center justify-center space-x-2 text-sm text-gray-600">
            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-300">
              Última atualização: Janeiro 2024
            </Badge>
          </div>
          
          <div className="flex space-x-3">
            <Button 
              onClick={onAccept}
              className="flex-1 bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white shadow-lg"
              size="lg"
            >
              ✅ Aceito os Termos
            </Button>
            
            <Button 
              onClick={onDecline}
              variant="outline" 
              className="flex-1 border-red-300 text-red-600 hover:bg-red-50"
              size="lg"
            >
              ❌ Não Aceito
            </Button>
          </div>
          
          <div className="text-center">
            <p className="text-xs text-gray-500">
              Ao aceitar, você concorda com o uso responsável dos seus dados para uma experiência personalizada
            </p>
            
            {/* Botão de revisar termos centralizado */}
            <Button 
              onClick={() => {
                // Scroll para o topo para revisar novamente
                const scrollArea = document.querySelector('[data-radix-scroll-area-viewport]');
                if (scrollArea) {
                  scrollArea.scrollTop = 0;
                }
              }}
              variant="ghost" 
              className="mt-2 text-blue-600 hover:bg-blue-50 text-xs h-8"
            >
              📖 Revisar Termos Novamente
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}