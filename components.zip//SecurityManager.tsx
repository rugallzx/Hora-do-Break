import React, { useEffect } from 'react';
import { toast } from 'sonner@2.0.3';

interface UserData {
  dailyScreenTime: number;
  coins: number;
  level: number;
  xp: number;
  avatarConfig: {
    body: string;
    eyes: string;
    accessory: string;
  };
  lastBreakTime: number;
  sessionStartTime: number;
  weeklyData: Array<{
    date: string;
    screenTime: number;
    missionsCompleted: number;
  }>;
  completedMissions: string[];
  lastSync?: string;
  integrityHash?: string;
  lastValidation?: number;
}

interface SecurityManagerProps {
  userData: UserData;
  onSecurityViolation: () => void;
  children: React.ReactNode;
}

export function SecurityManager({ userData, onSecurityViolation, children }: SecurityManagerProps) {
  // Função para criar hash de integridade dos dados críticos
  const createIntegrityHash = (data: UserData): string => {
    const criticalData = {
      coins: data.coins,
      level: data.level,
      xp: data.xp,
      completedMissions: data.completedMissions?.sort() || [],
      dailyScreenTime: data.dailyScreenTime
    };
    
    // Simple hash function (em produção usaria crypto)
    const str = JSON.stringify(criticalData);
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32bit integer
    }
    return hash.toString();
  };

  // Validar limites realísticos
  const validateRealisticLimits = (data: UserData): boolean => {
    // Limite máximo de moedas por dia (assumindo 24h de uso ativo)
    const maxCoinsPerDay = 500; // Ajustável conforme game design
    
    // Limite máximo de XP por dia
    const maxXPPerDay = 1000;
    
    // Limite máximo de tempo de tela por dia (12 horas)
    const maxScreenTimePerDay = 12 * 60;
    
    // Verificar se os valores estão dentro dos limites
    if (data.coins > maxCoinsPerDay * 7) { // Uma semana de limite
      console.warn('Security: Coins exceeding realistic limit');
      return false;
    }
    
    if (data.xp > maxXPPerDay * 30) { // Um mês de limite
      console.warn('Security: XP exceeding realistic limit');
      return false;
    }
    
    if (data.dailyScreenTime > maxScreenTimePerDay) {
      console.warn('Security: Daily screen time exceeding realistic limit');
      return false;
    }
    
    return true;
  };

  // Validar progressão lógica
  const validateProgression = (data: UserData): boolean => {
    // Verificar se o nível corresponde ao XP
    const calculateExpectedLevel = (xp: number) => {
      let level = 1;
      let requiredXP = 100;
      let totalXP = 0;
      
      while (totalXP + requiredXP <= xp) {
        totalXP += requiredXP;
        level++;
        requiredXP = Math.floor(requiredXP * 1.25);
      }
      
      return level;
    };
    
    const expectedLevel = calculateExpectedLevel(data.xp);
    if (Math.abs(data.level - expectedLevel) > 1) {
      console.warn('Security: Level-XP mismatch detected');
      return false;
    }
    
    return true;
  };

  // Validar timestamps
  const validateTimestamps = (data: UserData): boolean => {
    const now = Date.now();
    const oneWeekAgo = now - (7 * 24 * 60 * 60 * 1000);
    
    // Verificar se os timestamps são realísticos
    if (data.lastBreakTime > now || data.lastBreakTime < oneWeekAgo) {
      // Permitir timestamps no futuro próximo (5 minutos) para diferenças de relógio
      if (data.lastBreakTime > now + (5 * 60 * 1000)) {
        console.warn('Security: Invalid lastBreakTime timestamp');
        return false;
      }
    }
    
    if (data.sessionStartTime > now || data.sessionStartTime < oneWeekAgo) {
      if (data.sessionStartTime > now + (5 * 60 * 1000)) {
        console.warn('Security: Invalid sessionStartTime timestamp');
        return false;
      }
    }
    
    return true;
  };

  // Validar configuração do avatar
  const validateAvatarConfig = (data: UserData): boolean => {
    const validBodyColors = ['happy', 'tired', 'energetic', 'calm', 'fire', 'pink', 'orange', 'cyan', 'brown', 'gold', 'rainbow'];
    const validEyes = ['normal', 'sleepy', 'excited', 'star', 'heart', 'diamond', 'robot', 'wink', 'angry'];
    const validAccessories = ['none', 'glasses', 'hat', 'mask', 'chain', 'crown'];
    
    if (!validBodyColors.includes(data.avatarConfig.body)) {
      console.warn('Security: Invalid avatar body color');
      return false;
    }
    
    if (!validEyes.includes(data.avatarConfig.eyes)) {
      console.warn('Security: Invalid avatar eyes');
      return false;
    }
    
    if (!validAccessories.includes(data.avatarConfig.accessory)) {
      console.warn('Security: Invalid avatar accessory');
      return false;
    }
    
    return true;
  };

  // Função principal de validação
  const validateUserData = (data: UserData): boolean => {
    try {
      // Validações básicas de tipo
      if (typeof data.coins !== 'number' || data.coins < 0) {
        console.warn('Security: Invalid coins value');
        return false;
      }
      
      if (typeof data.xp !== 'number' || data.xp < 0) {
        console.warn('Security: Invalid XP value');
        return false;
      }
      
      if (typeof data.level !== 'number' || data.level < 1 || data.level > 50) {
        console.warn('Security: Invalid level value');
        return false;
      }
      
      if (typeof data.dailyScreenTime !== 'number' || data.dailyScreenTime < 0) {
        console.warn('Security: Invalid screen time value');
        return false;
      }
      
      // Validações específicas
      if (!validateRealisticLimits(data)) return false;
      if (!validateProgression(data)) return false;
      if (!validateTimestamps(data)) return false;
      if (!validateAvatarConfig(data)) return false;
      
      // Validar integridade hash (se existir)
      if (data.integrityHash) {
        const currentHash = createIntegrityHash(data);
        if (currentHash !== data.integrityHash) {
          console.warn('Security: Data integrity hash mismatch');
          return false;
        }
      }
      
      return true;
    } catch (error) {
      console.error('Security: Validation error', error);
      return false;
    }
  };

  // Detectar modificações suspeitas
  const detectSuspiciousActivity = (data: UserData): boolean => {
    const now = Date.now();
    const lastValidation = data.lastValidation || now;
    const timeDiff = now - lastValidation;
    
    // Se passou muito pouco tempo mas os dados mudaram drasticamente
    if (timeDiff < 60000) { // Menos de 1 minuto
      const previousData = JSON.parse(localStorage.getItem('screenTimeApp_backup') || '{}');
      
      if (previousData.coins && (data.coins - previousData.coins) > 100) {
        console.warn('Security: Suspicious coin increase detected');
        return true;
      }
      
      if (previousData.xp && (data.xp - previousData.xp) > 500) {
        console.warn('Security: Suspicious XP increase detected');
        return true;
      }
    }
    
    return false;
  };

  // Monitoramento de segurança
  useEffect(() => {
    const performSecurityCheck = () => {
      try {
        // Backup dos dados atuais
        localStorage.setItem('screenTimeApp_backup', JSON.stringify(userData));
        
        // Validar dados
        if (!validateUserData(userData)) {
          toast.error('🚨 Dados inconsistentes detectados! Aplicação será reiniciada.');
          onSecurityViolation();
          return;
        }
        
        // Detectar atividade suspeita
        if (detectSuspiciousActivity(userData)) {
          toast.warning('⚠️ Atividade suspeita detectada. Monitorando...');
          // Não bloqueia, apenas avisa
        }
        
        // Monitoramento de console
        const originalConsole = window.console;
        let consoleWarnings = 0;
        
        window.console = {
          ...originalConsole,
          log: (...args) => {
            originalConsole.log(...args);
            // Detectar tentativas de debug/hack
            const message = args.join(' ').toLowerCase();
            if (message.includes('localstorage') || message.includes('hack') || message.includes('cheat')) {
              consoleWarnings++;
              if (consoleWarnings > 3) {
                toast.error('🚨 Atividade suspeita no console detectada!');
              }
            }
          }
        };
        
        // Verificação periódica
        const securityInterval = setInterval(() => {
          const currentData = JSON.parse(localStorage.getItem('screenTimeApp') || '{}');
          if (!validateUserData(currentData)) {
            toast.error('🚨 Violação de segurança detectada!');
            onSecurityViolation();
            clearInterval(securityInterval);
          }
        }, 30000); // Verificar a cada 30 segundos
        
        return () => {
          clearInterval(securityInterval);
          window.console = originalConsole;
        };
      } catch (error) {
        console.error('Security Manager Error:', error);
      }
    };
    
    performSecurityCheck();
  }, [userData, onSecurityViolation]);

  // Detectar ferramentas de desenvolvedor
  useEffect(() => {
    let devtools = false;
    
    const detectDevTools = () => {
      const threshold = 160;
      
      setInterval(() => {
        if (window.outerHeight - window.innerHeight > threshold || 
            window.outerWidth - window.innerWidth > threshold) {
          if (!devtools) {
            devtools = true;
            console.warn('Developer tools detected');
            toast.warning('🔧 Ferramentas de desenvolvedor detectadas. O app está sendo monitorado por segurança.');
          }
        } else {
          devtools = false;
        }
      }, 500);
    };
    
    detectDevTools();
  }, []);

  return <>{children}</>;
}

// Função utilitária para criar hash de integridade
export const createUserDataHash = (userData: UserData): string => {
  const criticalData = {
    coins: userData.coins,
    level: userData.level,
    xp: userData.xp,
    completedMissions: userData.completedMissions?.sort() || [],
    dailyScreenTime: userData.dailyScreenTime
  };
  
  const str = JSON.stringify(criticalData);
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return hash.toString();
};