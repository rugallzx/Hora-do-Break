import React, { useState, useEffect } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { toast } from 'sonner@2.0.3';
import { Smartphone, Monitor, Wifi, WifiOff, RefreshCw, AlertCircle } from 'lucide-react';

interface ScreenTimeData {
  totalTime: number; // em minutos
  appUsage: Array<{
    name: string;
    time: number;
    category: string;
  }>;
  pickups: number;
  notifications: number;
  timestamp: string;
}

interface ScreenTimeIntegrationProps {
  onScreenTimeUpdate: (time: number) => void;
  isAuthenticated: boolean;
}

export function ScreenTimeIntegration({ onScreenTimeUpdate, isAuthenticated }: ScreenTimeIntegrationProps) {
  const [screenTimeData, setScreenTimeData] = useState<ScreenTimeData | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [lastSync, setLastSync] = useState<Date | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Detectar tipo de dispositivo
  const getDeviceType = () => {
    const userAgent = navigator.userAgent.toLowerCase();
    if (/iphone|ipad|ipod/.test(userAgent)) return 'iOS';
    if (/android/.test(userAgent)) return 'Android';
    return 'Desktop';
  };

  const deviceType = getDeviceType();

  // Verificar se APIs de tempo de tela estão disponíveis
  const checkAPIAvailability = () => {
    // Screen Time API (iOS - através de WebKit)
    if (deviceType === 'iOS' && 'webkit' in window) {
      return { available: true, type: 'iOS Screen Time' };
    }

    // Digital Wellbeing API (Android - através de intents)
    if (deviceType === 'Android' && 'navigator' in window) {
      return { available: true, type: 'Android Digital Wellbeing' };
    }

    // Web APIs disponíveis
    if ('navigator' in window && 'getBattery' in navigator) {
      return { available: true, type: 'Web APIs' };
    }

    return { available: false, type: 'Não disponível' };
  };

  const apiStatus = checkAPIAvailability();

  // Conectar com APIs nativas do dispositivo
  const connectToDeviceAPI = async () => {
    setIsLoading(true);
    setError(null);

    try {
      if (deviceType === 'iOS') {
        await connectToiOSScreenTime();
      } else if (deviceType === 'Android') {
        await connectToAndroidDigitalWellbeing();
      } else {
        await connectToWebAPIs();
      }
    } catch (err: any) {
      setError(err.message || 'Erro ao conectar com API do dispositivo');
      console.error('Device API connection error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Integração com iOS Screen Time
  const connectToiOSScreenTime = async () => {
    // Verificar se temos acesso ao Screen Time
    if (!('webkit' in window) || !(window as any).webkit?.messageHandlers?.screenTime) {
      throw new Error('Screen Time API não disponível. Certifique-se de que o app tem permissões adequadas.');
    }

    try {
      // Solicitar dados do Screen Time
      const response = await new Promise((resolve, reject) => {
        (window as any).webkit.messageHandlers.screenTime.postMessage({
          action: 'requestScreenTime',
          timeframe: 'today'
        });

        // Listener para resposta
        (window as any).screenTimeCallback = (data: any) => {
          resolve(data);
        };

        // Timeout após 10 segundos
        setTimeout(() => reject(new Error('Timeout ao solicitar dados')), 10000);
      });

      const data = response as any;
      const screenTimeData: ScreenTimeData = {
        totalTime: Math.floor(data.totalScreenTime / 60000), // converter ms para minutos
        appUsage: data.applications?.map((app: any) => ({
          name: app.name,
          time: Math.floor(app.timeUsed / 60000),
          category: app.category || 'Other'
        })) || [],
        pickups: data.pickupCount || 0,
        notifications: data.notificationCount || 0,
        timestamp: new Date().toISOString()
      };

      setScreenTimeData(screenTimeData);
      setIsConnected(true);
      onScreenTimeUpdate(screenTimeData.totalTime);
      toast.success('Conectado ao Screen Time!');
      
    } catch (error) {
      throw new Error('Não foi possível acessar dados do Screen Time. Verifique as permissões.');
    }
  };

  // Integração com Android Digital Wellbeing
  const connectToAndroidDigitalWellbeing = async () => {
    try {
      // Verificar se temos interface Android disponível
      if (!(window as any).Android?.getScreenTime) {
        throw new Error('Interface Android não disponível');
      }

      const data = (window as any).Android.getScreenTime();
      const parsed = JSON.parse(data);

      const screenTimeData: ScreenTimeData = {
        totalTime: Math.floor(parsed.totalScreenTime / 60000),
        appUsage: parsed.appUsage?.map((app: any) => ({
          name: app.packageName,
          time: Math.floor(app.timeInForeground / 60000),
          category: app.category || 'Other'
        })) || [],
        pickups: parsed.devicePickups || 0,
        notifications: parsed.notifications || 0,
        timestamp: new Date().toISOString()
      };

      setScreenTimeData(screenTimeData);
      setIsConnected(true);
      onScreenTimeUpdate(screenTimeData.totalTime);
      toast.success('Conectado ao Digital Wellbeing!');

    } catch (error) {
      throw new Error('Não foi possível acessar Digital Wellbeing. Execute através do app nativo.');
    }
  };

  // Usar Web APIs como fallback
  const connectToWebAPIs = async () => {
    try {
      // Estimar tempo de tela baseado em atividade da página
      const startTime = Date.now();
      
      // Usar Performance API para rastrear tempo ativo
      const entries = performance.getEntriesByType('navigation');
      let estimatedTime = 0;

      if (entries.length > 0) {
        const navigation = entries[0] as PerformanceNavigationTiming;
        estimatedTime = Math.floor((Date.now() - navigation.loadEventEnd) / 60000);
      }

      // Usar dados salvos localmente se disponíveis
      const savedData = localStorage.getItem('webScreenTimeData');
      if (savedData) {
        const parsed = JSON.parse(savedData);
        estimatedTime = parsed.totalTime || estimatedTime;
      }

      const screenTimeData: ScreenTimeData = {
        totalTime: estimatedTime,
        appUsage: [
          {
            name: 'Navegador Web',
            time: estimatedTime,
            category: 'Productivity'
          }
        ],
        pickups: 1,
        notifications: 0,
        timestamp: new Date().toISOString()
      };

      setScreenTimeData(screenTimeData);
      setIsConnected(true);
      onScreenTimeUpdate(screenTimeData.totalTime);
      toast.success('Usando Web APIs para estimativa de tempo de tela');

    } catch (error) {
      throw new Error('Não foi possível estimar tempo de tela');
    }
  };

  // Sincronizar com servidor
  const syncWithServer = async () => {
    if (!isAuthenticated || !screenTimeData) return;

    try {
      const accessToken = localStorage.getItem('supabase_access_token');
      const deviceId = localStorage.getItem('device_id') || 'web_' + Date.now();
      
      if (!localStorage.getItem('device_id')) {
        localStorage.setItem('device_id', deviceId);
      }

      const response = await fetch(`${window.location.origin}/functions/v1/make-server-187b714d/screen-time`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`
        },
        body: JSON.stringify({
          screenTimeData,
          deviceId
        })
      });

      if (response.ok) {
        setLastSync(new Date());
        toast.success('Dados sincronizados com servidor');
      }
    } catch (error) {
      console.error('Sync error:', error);
      toast.error('Erro ao sincronizar dados');
    }
  };

  // Auto-sync a cada 30 minutos
  useEffect(() => {
    if (isConnected && isAuthenticated) {
      const interval = setInterval(syncWithServer, 30 * 60 * 1000);
      return () => clearInterval(interval);
    }
  }, [isConnected, isAuthenticated, screenTimeData]);

  // Atualizar dados a cada 5 minutos quando conectado
  useEffect(() => {
    if (isConnected) {
      const interval = setInterval(() => {
        if (deviceType === 'Web' && screenTimeData) {
          // Incrementar tempo estimado
          const newTime = screenTimeData.totalTime + 5;
          const updatedData = { ...screenTimeData, totalTime: newTime };
          setScreenTimeData(updatedData);
          onScreenTimeUpdate(newTime);
          
          // Salvar localmente
          localStorage.setItem('webScreenTimeData', JSON.stringify(updatedData));
        }
      }, 5 * 60 * 1000);

      return () => clearInterval(interval);
    }
  }, [isConnected, screenTimeData, deviceType]);

  return (
    <Card className="p-6">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            {deviceType === 'iOS' && <Smartphone className="h-5 w-5 text-blue-500" />}
            {deviceType === 'Android' && <Smartphone className="h-5 w-5 text-green-500" />}
            {deviceType === 'Desktop' && <Monitor className="h-5 w-5 text-gray-500" />}
            <h3>Integração com Dispositivo</h3>
          </div>
          <div className="flex items-center space-x-2">
            {isConnected ? (
              <Badge variant="default" className="bg-green-500">
                <Wifi className="h-3 w-3 mr-1" />
                Conectado
              </Badge>
            ) : (
              <Badge variant="secondary">
                <WifiOff className="h-3 w-3 mr-1" />
                Desconectado
              </Badge>
            )}
          </div>
        </div>

        {/* Status da API */}
        <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Dispositivo: {deviceType}</p>
              <p className="text-sm text-muted-foreground">API: {apiStatus.type}</p>
            </div>
            <Badge variant={apiStatus.available ? 'default' : 'destructive'}>
              {apiStatus.available ? 'Disponível' : 'Não disponível'}
            </Badge>
          </div>
        </div>

        {/* Dados do tempo de tela */}
        {screenTimeData && (
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-4">
              <div className="p-3 bg-gray-50 rounded-lg">
                <p className="text-sm text-muted-foreground">Tempo Total</p>
                <p className="font-semibold">{Math.floor(screenTimeData.totalTime / 60)}h {screenTimeData.totalTime % 60}m</p>
              </div>
              <div className="p-3 bg-gray-50 rounded-lg">
                <p className="text-sm text-muted-foreground">Apps Usados</p>
                <p className="font-semibold">{screenTimeData.appUsage.length}</p>
              </div>
            </div>

            {screenTimeData.appUsage.length > 0 && (
              <div>
                <h4 className="font-medium mb-2">Apps mais usados:</h4>
                <div className="space-y-2">
                  {screenTimeData.appUsage.slice(0, 3).map((app, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <span className="text-sm">{app.name}</span>
                      <span className="text-sm text-muted-foreground">
                        {Math.floor(app.time / 60)}h {app.time % 60}m
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Error display */}
        {error && (
          <div className="p-3 bg-red-50 rounded-lg border border-red-200">
            <div className="flex items-start space-x-2">
              <AlertCircle className="h-4 w-4 text-red-500 mt-0.5" />
              <div>
                <p className="text-sm text-red-800">{error}</p>
                {deviceType !== 'Web' && (
                  <p className="text-xs text-red-600 mt-1">
                    Dica: Para melhor integração, use o app nativo do dispositivo.
                  </p>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Controles */}
        <div className="flex space-x-2">
          <Button
            onClick={connectToDeviceAPI}
            disabled={isLoading}
            className="flex-1"
          >
            {isLoading && <RefreshCw className="h-4 w-4 mr-2 animate-spin" />}
            {isConnected ? 'Reconectar' : 'Conectar'}
          </Button>

          {isConnected && isAuthenticated && (
            <Button
              variant="outline"
              onClick={syncWithServer}
            >
              Sincronizar
            </Button>
          )}
        </div>

        {lastSync && (
          <p className="text-xs text-muted-foreground text-center">
            Última sincronização: {lastSync.toLocaleTimeString()}
          </p>
        )}

        {/* Instruções */}
        <div className="p-3 bg-yellow-50 rounded-lg border border-yellow-200">
          <h4 className="font-medium text-yellow-800 mb-1">Como usar:</h4>
          <ul className="text-sm text-yellow-700 space-y-1">
            {deviceType === 'iOS' && (
              <>
                <li>• Ative o Screen Time nas configurações do iOS</li>
                <li>• Permita acesso aos dados para este app</li>
                <li>• Use através do Safari ou app nativo</li>
              </>
            )}
            {deviceType === 'Android' && (
              <>
                <li>• Ative o Digital Wellbeing nas configurações</li>
                <li>• Use através do app nativo do Android</li>
                <li>• Permita acesso aos dados de uso</li>
              </>
            )}
            {deviceType === 'Desktop' && (
              <>
                <li>• Dados serão estimados através do navegador</li>
                <li>• Para dados precisos, use no dispositivo móvel</li>
                <li>• Mantenha a aba ativa para melhor rastreamento</li>
              </>
            )}
          </ul>
        </div>
      </div>
    </Card>
  );
}