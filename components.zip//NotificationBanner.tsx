import React from 'react';
import { Alert, AlertDescription } from './ui/alert';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { X, AlertTriangle, Info, CheckCircle, Clock, Zap } from 'lucide-react';

interface NotificationBannerProps {
  screenTimePercent: number;
  currentSessionTime: number;
  energy: number;
  dailyStreak?: number;
  onDismiss?: (type: string) => void;
  dismissedAlerts?: string[];
}

export function NotificationBanner({ 
  screenTimePercent, 
  currentSessionTime, 
  energy, 
  dailyStreak = 0,
  onDismiss,
  dismissedAlerts = []
}: NotificationBannerProps) {
  const alerts = [];

  // Critical screen time alert
  if (screenTimePercent > 90 && !dismissedAlerts.includes('screentime-critical')) {
    alerts.push({
      id: 'screentime-critical',
      type: 'destructive',
      icon: AlertTriangle,
      title: '🚨 Limite de Tempo Crítico!',
      description: 'Você já usou 90% do seu tempo diário recomendado. Considere fazer uma pausa.',
      action: 'Fazer Pausa Agora'
    });
  }

  // High screen time warning
  if (screenTimePercent > 75 && screenTimePercent <= 90 && !dismissedAlerts.includes('screentime-warning')) {
    alerts.push({
      id: 'screentime-warning',
      type: 'warning',
      icon: Clock,
      title: '⚠️ Alto Tempo de Tela',
      description: 'Você está próximo do limite diário. Que tal começar a reduzir o uso?',
      action: 'Ver Dicas'
    });
  }

  // Long session alert
  if (currentSessionTime > 45 && !dismissedAlerts.includes('session-long')) {
    alerts.push({
      id: 'session-long',
      type: 'warning',
      icon: Clock,
      title: '📱 Sessão Muito Longa',
      description: `Você está há ${currentSessionTime} minutos sem pausa. Seus olhos precisam descansar!`,
      action: 'Pausar Agora'
    });
  }

  // Low energy alert
  if (energy < 30 && !dismissedAlerts.includes('energy-low')) {
    alerts.push({
      id: 'energy-low',
      type: 'warning',
      icon: Zap,
      title: '🔋 Energia Baixa do Avatar',
      description: 'Seu avatar está exausto! Faça uma pausa para restaurar a energia.',
      action: 'Restaurar Energia'
    });
  }

  // Daily streak celebration
  if (dailyStreak > 0 && dailyStreak % 7 === 0 && !dismissedAlerts.includes(`streak-${dailyStreak}`)) {
    alerts.push({
      id: `streak-${dailyStreak}`,
      type: 'success',
      icon: CheckCircle,
      title: `🎉 ${dailyStreak} Dias de Sequência!`,
      description: 'Parabéns! Você está mantendo um ótimo controle do tempo de tela!',
      action: 'Continuar'
    });
  }

  // Good usage day
  if (screenTimePercent < 50 && currentSessionTime < 30 && !dismissedAlerts.includes('good-day')) {
    alerts.push({
      id: 'good-day',
      type: 'info',
      icon: Info,
      title: '✅ Ótimo Controle!',
      description: 'Você está fazendo um excelente trabalho controlando o tempo de tela hoje!',
      action: 'Manter Assim'
    });
  }

  if (alerts.length === 0) return null;

  const getAlertClass = (type: string) => {
    switch (type) {
      case 'destructive':
        return 'border-red-300 bg-red-50 text-red-800';
      case 'warning':
        return 'border-yellow-300 bg-yellow-50 text-yellow-800';
      case 'success':
        return 'border-green-300 bg-green-50 text-green-800';
      case 'info':
        return 'border-blue-300 bg-blue-50 text-blue-800';
      default:
        return 'border-gray-300 bg-gray-50 text-gray-800';
    }
  };

  return (
    <div className="space-y-3">
      {alerts.slice(0, 2).map((alert) => { // Show max 2 alerts
        const Icon = alert.icon;
        return (
          <Alert key={alert.id} className={`${getAlertClass(alert.type)} relative animate-in slide-in-from-top duration-500`}>
            <Icon className="h-4 w-4" />
            <AlertDescription className="flex items-center justify-between">
              <div className="flex-1 mr-4">
                <div className="font-medium mb-1">{alert.title}</div>
                <div className="text-sm opacity-90">{alert.description}</div>
              </div>
              <div className="flex items-center space-x-2">
                {alert.action && (
                  <Button 
                    size="sm" 
                    variant="outline" 
                    className="text-xs h-7"
                    onClick={() => {
                      // Handle action based on alert type
                      if (alert.id.includes('screentime') || alert.id.includes('session') || alert.id.includes('energy')) {
                        // Could trigger break dialog or navigation
                      }
                      onDismiss?.(alert.id);
                    }}
                  >
                    {alert.action}
                  </Button>
                )}
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-7 w-7 p-0 opacity-70 hover:opacity-100"
                  onClick={() => onDismiss?.(alert.id)}
                >
                  <X className="h-3 w-3" />
                </Button>
              </div>
            </AlertDescription>
          </Alert>
        );
      })}
    </div>
  );
}