import React, { useState, useEffect } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Switch } from './ui/switch';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { toast } from 'sonner@2.0.3';
import { Bell, BellOff, Clock, Target, Award, Settings, Smartphone } from 'lucide-react';

interface NotificationSettings {
  breakReminders: boolean;
  breakInterval: number; // em minutos
  dailyGoalReminder: boolean;
  goalReminderTime: string; // HH:MM format
  missionReminders: boolean;
  weeklyReport: boolean;
  encouragementMessages: boolean;
}

interface NotificationManagerProps {
  userData: any;
  onSettingsUpdate: (settings: NotificationSettings) => void;
}

export function NotificationManager({ userData, onSettingsUpdate }: NotificationManagerProps) {
  const [isSupported, setIsSupported] = useState(false);
  const [permission, setPermission] = useState<NotificationPermission>('default');
  const [isServiceWorkerReady, setIsServiceWorkerReady] = useState(false);
  const [settings, setSettings] = useState<NotificationSettings>({
    breakReminders: true,
    breakInterval: 40,
    dailyGoalReminder: true,
    goalReminderTime: '18:00',
    missionReminders: true,
    weeklyReport: true,
    encouragementMessages: true
  });

  // Verificar suporte e registrar Service Worker
  useEffect(() => {
    try {
      checkNotificationSupport();
      registerServiceWorker();
      loadSettings();
    } catch (error) {
      console.error('Error during NotificationManager initialization:', error);
    }
  }, []);

  const checkNotificationSupport = () => {
    const basicSupport = 'Notification' in window;
    const swSupport = 'serviceWorker' in navigator;
    const isValidEnvironment = window.location.protocol === 'https:' || 
                             window.location.hostname === 'localhost' ||
                             window.location.hostname === '127.0.0.1';
    
    setIsSupported(basicSupport);
    
    if (basicSupport) {
      setPermission(Notification.permission);
    }

    // Log informações de debug
    console.log('Notification Support:', {
      basic: basicSupport,
      serviceWorker: swSupport,
      environment: isValidEnvironment,
      permission: basicSupport ? Notification.permission : 'N/A'
    });
  };

  const registerServiceWorker = async () => {
    if ('serviceWorker' in navigator) {
      try {
        // Verificar se estamos em um ambiente que suporta Service Workers adequadamente
        const isValidEnvironment = window.location.protocol === 'https:' || 
                                 window.location.hostname === 'localhost' ||
                                 window.location.hostname === '127.0.0.1';
        
        if (!isValidEnvironment) {
          console.log('Service Worker não suportado neste ambiente');
          setIsServiceWorkerReady(false);
          return;
        }

        // Create service worker code dynamically
        const swCode = `
          const CACHE_NAME = 'screen-balance-notifications-v1';
          
          self.addEventListener('install', (event) => {
            console.log('Service Worker installing');
            self.skipWaiting();
          });

          self.addEventListener('activate', (event) => {
            console.log('Service Worker activating');
            event.waitUntil(self.clients.claim());
          });

          self.addEventListener('notificationclick', (event) => {
            event.notification.close();
            
            // Abrir ou focar na aba do app
            event.waitUntil(
              self.clients.matchAll({ type: 'window' }).then((clients) => {
                const client = clients.find(c => c.url.includes('localhost') || c.url.includes('supabase'));
                if (client) {
                  return client.focus();
                } else {
                  return self.clients.openWindow('/');
                }
              })
            );
          });

          self.addEventListener('message', (event) => {
            if (event.data.type === 'SCHEDULE_NOTIFICATION') {
              const { title, body, delay, tag } = event.data.payload;
              
              setTimeout(() => {
                self.registration.showNotification(title, {
                  body,
                  icon: '/favicon.ico',
                  tag,
                  badge: '/favicon.ico',
                  requireInteraction: true,
                  actions: [
                    {
                      action: 'take_break',
                      title: 'Fazer Pausa'
                    },
                    {
                      action: 'snooze',
                      title: 'Adiar 10min'
                    }
                  ]
                });
              }, delay);
            }
          });
        `;

        const blob = new Blob([swCode], { type: 'application/javascript' });
        const swUrl = URL.createObjectURL(blob);

        const registration = await navigator.serviceWorker.register(swUrl, {
          scope: '/'
        });
        console.log('Service Worker registrado:', registration);
        setIsServiceWorkerReady(true);
        
        // Clean up the blob URL
        URL.revokeObjectURL(swUrl);
      } catch (error) {
        console.error('Erro ao registrar Service Worker:', error);
        // Não mostrar erro para usuário em ambientes de desenvolvimento
        if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
          toast.error('Erro ao configurar notificações avançadas');
        }
        setIsServiceWorkerReady(false);
      }
    }
  };

  const loadSettings = () => {
    try {
      if (typeof window !== 'undefined') {
        const savedSettings = localStorage.getItem('notificationSettings');
        if (savedSettings) {
          const parsed = JSON.parse(savedSettings);
          setSettings(parsed);
          onSettingsUpdate(parsed);
        }
      }
    } catch (error) {
      console.error('Error loading notification settings:', error);
    }
  };

  const saveSettings = (newSettings: NotificationSettings) => {
    try {
      setSettings(newSettings);
      if (typeof window !== 'undefined') {
        localStorage.setItem('notificationSettings', JSON.stringify(newSettings));
      }
      onSettingsUpdate(newSettings);
      toast.success('Configurações de notificações salvas');
    } catch (error) {
      console.error('Error saving notification settings:', error);
      toast.error('Erro ao salvar configurações');
    }
  };

  const requestPermission = async () => {
    if (!isSupported) {
      toast.error('Notificações não são suportadas neste navegador');
      return;
    }

    try {
      const permission = await Notification.requestPermission();
      setPermission(permission);

      if (permission === 'granted') {
        toast.success('Permissão para notificações concedida!');
        scheduleNotifications();
      } else if (permission === 'denied') {
        toast.error('Permissão para notificações negada');
      }
    } catch (error) {
      console.error('Erro ao solicitar permissão:', error);
      toast.error('Erro ao solicitar permissão para notificações');
    }
  };

  const scheduleNotifications = () => {
    if (permission !== 'granted') return;

    // Agendar lembrete de pausa
    if (settings.breakReminders) {
      scheduleBreakReminder();
    }

    // Agendar lembrete de meta diária
    if (settings.dailyGoalReminder) {
      scheduleDailyGoalReminder();
    }

    // Agendar lembretes de missões
    if (settings.missionReminders) {
      scheduleMissionReminders();
    }
  };

  const scheduleBreakReminder = () => {
    const delay = settings.breakInterval * 60 * 1000; // converter para ms
    
    if (isServiceWorkerReady && navigator.serviceWorker.controller) {
      navigator.serviceWorker.controller.postMessage({
        type: 'SCHEDULE_NOTIFICATION',
        payload: {
          title: '☕ Hora do Break!',
          body: `Você está usando a tela há ${settings.breakInterval} minutos. Que tal fazer uma pausa de 5 minutos?`,
          delay,
          tag: 'break-reminder'
        }
      });
    } else if (permission === 'granted') {
      // Fallback para notificações básicas sem Service Worker
      setTimeout(() => {
        if (document.hidden || !document.hasFocus()) {
          new Notification('☕ Hora do Break!', {
            body: `Você está usando a tela há ${settings.breakInterval} minutos. Que tal fazer uma pausa de 5 minutos?`,
            icon: '/favicon.ico',
            tag: 'break-reminder'
          });
        }
      }, delay);
    }
  };

  const scheduleDailyGoalReminder = () => {
    const now = new Date();
    const [hours, minutes] = settings.goalReminderTime.split(':').map(Number);
    const reminderTime = new Date();
    reminderTime.setHours(hours, minutes, 0, 0);

    // Se já passou da hora hoje, agendar para amanhã
    if (reminderTime <= now) {
      reminderTime.setDate(reminderTime.getDate() + 1);
    }

    const delay = reminderTime.getTime() - now.getTime();

    if (isServiceWorkerReady && navigator.serviceWorker.controller) {
      navigator.serviceWorker.controller.postMessage({
        type: 'SCHEDULE_NOTIFICATION',
        payload: {
          title: '🎯 Como está sua meta hoje?',
          body: 'Verifique seu progresso e complete suas missões diárias!',
          delay,
          tag: 'daily-goal'
        }
      });
    } else if (permission === 'granted') {
      // Fallback para notificações básicas
      setTimeout(() => {
        if (document.hidden || !document.hasFocus()) {
          new Notification('🎯 Como está sua meta hoje?', {
            body: 'Verifique seu progresso e complete suas missões diárias!',
            icon: '/favicon.ico',
            tag: 'daily-goal'
          });
        }
      }, delay);
    }
  };

  const scheduleMissionReminders = () => {
    // Lembrar sobre missões não completadas a cada 3 horas
    const delay = 3 * 60 * 60 * 1000; // 3 horas

    if (isServiceWorkerReady && navigator.serviceWorker.controller) {
      navigator.serviceWorker.controller.postMessage({
        type: 'SCHEDULE_NOTIFICATION',
        payload: {
          title: '🏆 Missões Disponíveis',
          body: 'Você tem missões pendentes para completar hoje!',
          delay,
          tag: 'mission-reminder'
        }
      });
    } else if (permission === 'granted') {
      // Fallback para notificações básicas
      setTimeout(() => {
        if (document.hidden || !document.hasFocus()) {
          new Notification('🏆 Missões Disponíveis', {
            body: 'Você tem missões pendentes para completar hoje!',
            icon: '/favicon.ico',
            tag: 'mission-reminder'
          });
        }
      }, delay);
    }
  };

  const sendTestNotification = () => {
    try {
      if (!isSupported) {
        toast.error('Notificações não são suportadas neste navegador');
        return;
      }

      if (permission !== 'granted') {
        toast.error('Permissão para notificações necessária. Clique em "Ativar Notificações" primeiro.');
        return;
      }

      // Tentar criar notificação
      try {
        const notification = new Notification('☕ Hora do Break - Teste!', {
          body: 'Suas notificações estão funcionando perfeitamente! 🎉',
          icon: 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%23f97316"><path d="M2 21h20v-2H2v2zm1.15-4.05L4 15.47l.85 1.48L8 14.93l3.15 2.02L12 15.47l.85 1.48L16 14.93l3.15 2.02L20 15.47l.85 1.48H22v-2.4L19.5 12l2.5-2.55V7.07L20 8.53l-.85-1.48L16 9.07l-3.15-2.02L12 8.53l-.85-1.48L8 9.07l-3.15-2.02L4 8.53l-.85-1.48H2v2.4L4.5 12L2 14.55v2.4z"/></svg>',
          tag: 'test-notification',
          requireInteraction: false,
          silent: false
        });

        // Definir comportamento quando a notificação for clicada
        notification.onclick = function() {
          window.focus();
          notification.close();
          toast.success('Notificação clicada! Tudo funcionando corretamente.');
        };

        // Fechar automaticamente após 5 segundos se não foi clicada
        setTimeout(() => {
          if (notification) {
            notification.close();
          }
        }, 5000);

        toast.success('✅ Notificação de teste enviada com sucesso!', {
          description: 'Verifique se apareceu uma notificação na sua tela.'
        });

      } catch (notificationError) {
        console.error('Erro ao criar notificação:', notificationError);
        
        // Fallback: tentar com Service Worker se disponível
        if (isServiceWorkerReady && navigator.serviceWorker.controller) {
          navigator.serviceWorker.controller.postMessage({
            type: 'SCHEDULE_NOTIFICATION',
            payload: {
              title: '☕ Hora do Break - Teste!',
              body: 'Suas notificações estão funcionando via Service Worker! 🎉',
              delay: 0,
              tag: 'test-sw'
            }
          });
          toast.success('✅ Notificação de teste enviada via Service Worker!');
        } else {
          throw notificationError;
        }
      }
      
    } catch (error) {
      console.error('Error sending test notification:', error);
      
      // Mensagem de erro mais específica baseada no tipo de erro
      if (error.name === 'NotAllowedError') {
        toast.error('❌ Permissão para notificações foi negada pelo navegador');
      } else if (error.name === 'AbortError') {
        toast.error('❌ Notificação foi cancelada');
      } else {
        toast.error('❌ Erro ao enviar notificação de teste', {
          description: 'Verifique se as notificações estão ativadas no seu navegador.'
        });
      }
    }
  };

  const sendEncouragementNotification = (message: string) => {
    try {
      if (permission !== 'granted' || !settings.encouragementMessages) return;

      if ('Notification' in window) {
        new Notification('💪 Você consegue!', {
          body: message,
          icon: '/favicon.ico',
          tag: 'encouragement'
        });
      }
    } catch (error) {
      console.error('Error sending encouragement notification:', error);
    }
  };

  // Efeito para enviar notificações de encorajamento baseadas no progresso
  useEffect(() => {
    if (userData.dailyScreenTime <= 120 && settings.encouragementMessages) {
      sendEncouragementNotification('Excelente controle de tempo de tela hoje! Continue assim! 🎉');
    } else if (userData.dailyScreenTime >= 240 && settings.encouragementMessages) {
      sendEncouragementNotification('Tempo de tela alto hoje. Que tal fazer uma pausa? 😊');
    }
  }, [userData.dailyScreenTime, settings.encouragementMessages]);

  // Re-agendar notificações quando as configurações mudarem
  useEffect(() => {
    if (permission === 'granted') {
      scheduleNotifications();
    }
  }, [settings, permission, isServiceWorkerReady]);

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2>Notificações e Lembretes</h2>
        <p className="text-muted-foreground">
          Configure lembretes para manter seus hábitos saudáveis
        </p>
      </div>

      {/* Status das notificações */}
      <Card className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            {permission === 'granted' ? (
              <Bell className="h-5 w-5 text-green-500" />
            ) : (
              <BellOff className="h-5 w-5 text-red-500" />
            )}
            <div>
              <h3>Status das Notificações</h3>
              <p className="text-sm text-muted-foreground">
                {!isSupported && 'Não suportado neste navegador'}
                {isSupported && permission === 'default' && 'Permissão não solicitada'}
                {isSupported && permission === 'granted' && 'Ativo e funcionando'}
                {isSupported && permission === 'denied' && 'Permissão negada'}
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Badge variant={permission === 'granted' ? 'default' : 'destructive'}>
              {permission === 'granted' ? 'Ativo' : 'Inativo'}
            </Badge>
            {isServiceWorkerReady && (
              <Badge variant="outline">Avançado</Badge>
            )}
            {!isServiceWorkerReady && permission === 'granted' && (
              <Badge variant="secondary">Básico</Badge>
            )}
          </div>
        </div>

        {permission !== 'granted' && (
          <div className="mt-4">
            <Button onClick={requestPermission} className="w-full">
              Ativar Notificações
            </Button>
          </div>
        )}
      </Card>

      {/* Configurações das notificações */}
      <Card className="p-6">
        <Tabs defaultValue="reminders">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="reminders">Lembretes</TabsTrigger>
            <TabsTrigger value="goals">Metas</TabsTrigger>
            <TabsTrigger value="advanced">Avançado</TabsTrigger>
          </TabsList>

          <TabsContent value="reminders" className="space-y-4 mt-4">
            <div className="space-y-4">
              {/* Lembretes de pausa */}
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center space-x-3">
                  <Clock className="h-4 w-4 text-blue-500" />
                  <div>
                    <h4>Lembretes de Pausa</h4>
                    <p className="text-sm text-muted-foreground">
                      Ser lembrado de fazer pausas regulares
                    </p>
                  </div>
                </div>
                <Switch
                  checked={settings.breakReminders}
                  onCheckedChange={(checked) => 
                    saveSettings({...settings, breakReminders: checked})
                  }
                />
              </div>

              {settings.breakReminders && (
                <div className="ml-7 space-y-2">
                  <Label>Intervalo entre pausas (minutos)</Label>
                  <Input
                    type="number"
                    value={settings.breakInterval}
                    onChange={(e) => 
                      saveSettings({...settings, breakInterval: parseInt(e.target.value) || 40})
                    }
                    min="15"
                    max="120"
                  />
                </div>
              )}

              {/* Lembretes de missões */}
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center space-x-3">
                  <Award className="h-4 w-4 text-purple-500" />
                  <div>
                    <h4>Lembretes de Missões</h4>
                    <p className="text-sm text-muted-foreground">
                      Ser lembrado sobre missões pendentes
                    </p>
                  </div>
                </div>
                <Switch
                  checked={settings.missionReminders}
                  onCheckedChange={(checked) => 
                    saveSettings({...settings, missionReminders: checked})
                  }
                />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="goals" className="space-y-4 mt-4">
            <div className="space-y-4">
              {/* Lembrete de meta diária */}
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center space-x-3">
                  <Target className="h-4 w-4 text-green-500" />
                  <div>
                    <h4>Lembrete de Meta Diária</h4>
                    <p className="text-sm text-muted-foreground">
                      Verificar progresso da meta diária
                    </p>
                  </div>
                </div>
                <Switch
                  checked={settings.dailyGoalReminder}
                  onCheckedChange={(checked) => 
                    saveSettings({...settings, dailyGoalReminder: checked})
                  }
                />
              </div>

              {settings.dailyGoalReminder && (
                <div className="ml-7 space-y-2">
                  <Label>Horário do lembrete</Label>
                  <Input
                    type="time"
                    value={settings.goalReminderTime}
                    onChange={(e) => 
                      saveSettings({...settings, goalReminderTime: e.target.value})
                    }
                  />
                </div>
              )}

              {/* Relatório semanal */}
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center space-x-3">
                  <Smartphone className="h-4 w-4 text-orange-500" />
                  <div>
                    <h4>Relatório Semanal</h4>
                    <p className="text-sm text-muted-foreground">
                      Receber relatório semanal às segundas-feiras
                    </p>
                  </div>
                </div>
                <Switch
                  checked={settings.weeklyReport}
                  onCheckedChange={(checked) => 
                    saveSettings({...settings, weeklyReport: checked})
                  }
                />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="advanced" className="space-y-4 mt-4">
            <div className="space-y-4">
              {/* Mensagens de encorajamento */}
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center space-x-3">
                  <Settings className="h-4 w-4 text-gray-500" />
                  <div>
                    <h4>Mensagens de Encorajamento</h4>
                    <p className="text-sm text-muted-foreground">
                      Receber mensagens motivacionais baseadas no progresso
                    </p>
                  </div>
                </div>
                <Switch
                  checked={settings.encouragementMessages}
                  onCheckedChange={(checked) => 
                    saveSettings({...settings, encouragementMessages: checked})
                  }
                />
              </div>

              {/* Teste de notificação */}
              <div className="p-3 border rounded-lg">
                <h4 className="mb-2">Testar Notificações</h4>
                <p className="text-sm text-muted-foreground mb-3">
                  Envie uma notificação de teste para verificar se está funcionando
                </p>
                <Button 
                  onClick={sendTestNotification} 
                  disabled={permission !== 'granted'}
                  variant="outline"
                >
                  Enviar Teste
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </Card>

      {/* Dicas */}
      <Card className="p-4 bg-blue-50 border-blue-200">
        <h4 className="flex items-center space-x-2 mb-2">
          <Bell className="h-4 w-4 text-blue-500" />
          <span>Dicas para Notificações</span>
        </h4>
        <ul className="text-sm text-muted-foreground space-y-1">
          <li>• Permita notificações para receber lembretes automáticos</li>
          <li>• Configure horários que funcionem melhor para sua rotina</li>
          <li>• Use o modo "não perturbe" quando necessário</li>
          <li>• Notificações funcionam mesmo com o app fechado</li>
        </ul>
      </Card>
    </div>
  );
}