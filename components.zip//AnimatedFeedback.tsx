import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface AnimatedFeedbackProps {
  trigger: boolean;
  type: 'break' | 'mission' | 'levelUp' | 'achievement';
  data?: {
    coins?: number;
    xp?: number;
    level?: number;
    title?: string;
  };
  onComplete?: () => void;
}

export function AnimatedFeedback({ trigger, type, data, onComplete }: AnimatedFeedbackProps) {
  const [show, setShow] = useState(false);

  useEffect(() => {
    if (trigger) {
      setShow(true);
      const timer = setTimeout(() => {
        setShow(false);
        onComplete?.();
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [trigger, onComplete]);

  const getAnimation = () => {
    switch (type) {
      case 'break':
        return {
          particles: '✨💙⭐🌟💫',
          color: 'from-blue-400 to-cyan-400',
          message: 'Pausa realizada!',
          icon: '☕'
        };
      case 'mission':
        return {
          particles: '🎯🏆⭐✨🎉',
          color: 'from-green-400 to-emerald-400',
          message: 'Missão completada!',
          icon: '🎯'
        };
      case 'levelUp':
        return {
          particles: '🌟⭐✨💫🎊',
          color: 'from-purple-400 to-pink-400',
          message: `Nível ${data?.level}!`,
          icon: '🎉'
        };
      case 'achievement':
        return {
          particles: '🏆👑⭐🎖️🏅',
          color: 'from-yellow-400 to-orange-400',
          message: data?.title || 'Conquista!',
          icon: '🏆'
        };
      default:
        return {
          particles: '✨⭐🌟💫',
          color: 'from-blue-400 to-purple-400',
          message: 'Parabéns!',
          icon: '🎉'
        };
    }
  };

  const animation = getAnimation();

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center pointer-events-none"
        >
          {/* Overlay escuro */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.6 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-black"
          />

          {/* Efeito de partículas */}
          <div className="absolute inset-0 overflow-hidden">
            {animation.particles.split('').map((particle, index) => (
              <motion.div
                key={index}
                initial={{
                  x: Math.random() * window.innerWidth,
                  y: window.innerHeight + 50,
                  scale: 0,
                  rotate: 0,
                }}
                animate={{
                  y: -50,
                  scale: [0, 1, 0.8, 0],
                  rotate: 360,
                  x: Math.random() * window.innerWidth,
                }}
                transition={{
                  duration: 2.5,
                  delay: index * 0.1,
                  ease: 'easeOut',
                }}
                className="absolute text-2xl"
              >
                {particle}
              </motion.div>
            ))}
          </div>

          {/* Círculo central animado */}
          <motion.div
            initial={{ scale: 0, rotate: -180 }}
            animate={{ scale: 1, rotate: 0 }}
            exit={{ scale: 0, rotate: 180 }}
            transition={{ 
              type: 'spring', 
              stiffness: 200, 
              damping: 20,
              duration: 0.8 
            }}
            className={`relative z-10 w-32 h-32 rounded-full bg-gradient-to-r ${animation.color} flex items-center justify-center shadow-2xl`}
          >
            <motion.div
              animate={{ 
                scale: [1, 1.2, 1],
                rotate: [0, 5, -5, 0]
              }}
              transition={{ 
                duration: 1.5, 
                repeat: Infinity,
                repeatType: 'reverse'
              }}
              className="text-4xl"
            >
              {animation.icon}
            </motion.div>

            {/* Anel animado */}
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ 
                duration: 2, 
                repeat: Infinity, 
                ease: 'linear' 
              }}
              className="absolute inset-0 rounded-full border-4 border-white border-opacity-30 border-dashed"
            />
          </motion.div>

          {/* Texto principal */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -50 }}
            transition={{ delay: 0.3 }}
            className="absolute z-10 text-center mt-48"
          >
            <motion.h2
              animate={{ 
                scale: [1, 1.05, 1] 
              }}
              transition={{ 
                duration: 1.5, 
                repeat: Infinity,
                repeatType: 'reverse'
              }}
              className="text-3xl font-bold text-white mb-2"
            >
              {animation.message}
            </motion.h2>
            
            {/* Recompensas */}
            {(data?.coins || data?.xp) && (
              <motion.div
                initial={{ opacity: 0, scale: 0 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.6 }}
                className="flex justify-center space-x-4 text-white"
              >
                {data.coins && (
                  <div className="flex items-center space-x-1 bg-yellow-500 rounded-full px-3 py-1">
                    <span className="text-sm">💰</span>
                    <span className="font-bold">+{data.coins}</span>
                  </div>
                )}
                {data.xp && (
                  <div className="flex items-center space-x-1 bg-purple-500 rounded-full px-3 py-1">
                    <span className="text-sm">⭐</span>
                    <span className="font-bold">+{data.xp}</span>
                  </div>
                )}
              </motion.div>
            )}
          </motion.div>

          {/* Ondas de energia */}
          <motion.div
            animate={{
              scale: [1, 2, 3],
              opacity: [0.6, 0.3, 0],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: 'easeOut',
            }}
            className={`absolute w-32 h-32 rounded-full bg-gradient-to-r ${animation.color} opacity-20`}
          />
          
          <motion.div
            animate={{
              scale: [1, 2.5, 4],
              opacity: [0.4, 0.2, 0],
            }}
            transition={{
              duration: 2.5,
              repeat: Infinity,
              ease: 'easeOut',
              delay: 0.5,
            }}
            className={`absolute w-32 h-32 rounded-full bg-gradient-to-r ${animation.color} opacity-20`}
          />
        </motion.div>
      )}
    </AnimatePresence>
  );
}