import React from 'react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { motion } from 'motion/react';
import { Flame, Calendar, Trophy, Target } from 'lucide-react';

interface StreakDisplayProps {
  currentStreak: number;
  longestStreak: number;
  lastBreakDate: string;
}

export function StreakDisplay({ currentStreak, longestStreak, lastBreakDate }: StreakDisplayProps) {
  const today = new Date().toISOString().split('T')[0];
  const isStreakActive = lastBreakDate === today;
  
  const getStreakColor = (streak: number) => {
    if (streak >= 30) return 'from-purple-500 to-pink-500';
    if (streak >= 14) return 'from-orange-500 to-red-500';
    if (streak >= 7) return 'from-yellow-500 to-orange-500';
    if (streak >= 3) return 'from-green-500 to-emerald-500';
    return 'from-blue-500 to-cyan-500';
  };

  const getStreakTitle = (streak: number) => {
    if (streak >= 30) return 'Lenda da Consistência';
    if (streak >= 14) return 'Mestre das Pausas';
    if (streak >= 7) return 'Semana Perfeita';
    if (streak >= 3) return 'Em Ritmo';
    return 'Começando';
  };

  const getStreakEmoji = (streak: number) => {
    if (streak >= 30) return '👑';
    if (streak >= 14) return '🏆';
    if (streak >= 7) return '⭐';
    if (streak >= 3) return '🔥';
    return '💪';
  };

  return (
    <div className="space-y-4">
      {/* Card principal do streak */}
      <Card className="p-6 bg-gradient-to-br from-orange-50 to-red-50 dark:from-orange-950 dark:to-red-950 border-orange-200 dark:border-orange-800">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <motion.div 
              className={`p-3 rounded-full bg-gradient-to-r ${getStreakColor(currentStreak)} shadow-lg`}
              animate={{ 
                scale: isStreakActive ? [1, 1.1, 1] : 1,
                rotate: isStreakActive ? [0, 5, -5, 0] : 0
              }}
              transition={{ 
                duration: 2, 
                repeat: isStreakActive ? Infinity : 0,
                repeatType: 'reverse'
              }}
            >
              <Flame className="h-6 w-6 text-white" />
            </motion.div>
            <div>
              <h3 className="text-lg font-bold">Sequência Atual</h3>
              <p className="text-sm text-muted-foreground">{getStreakTitle(currentStreak)}</p>
            </div>
          </div>
          <div className="text-right">
            <div className="text-3xl font-bold flex items-center">
              {currentStreak}
              <span className="text-lg ml-1">{getStreakEmoji(currentStreak)}</span>
            </div>
            <p className="text-sm text-muted-foreground">
              {currentStreak === 1 ? 'dia' : 'dias'}
            </p>
          </div>
        </div>

        <div className="space-y-3">
          {/* Status da sequência */}
          <div className="flex items-center justify-between p-3 bg-white/50 dark:bg-black/20 rounded-lg">
            <div className="flex items-center space-x-2">
              <Calendar className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm font-medium">Status de hoje</span>
            </div>
            <Badge 
              className={isStreakActive 
                ? 'bg-green-600 text-white' 
                : 'bg-orange-600 text-white'
              }
            >
              {isStreakActive ? '✅ Pausas feitas' : '⏳ Faça uma pausa'}
            </Badge>
          </div>

          {/* Recordes */}
          <div className="grid grid-cols-2 gap-3">
            <div className="text-center p-3 bg-white/50 dark:bg-black/20 rounded-lg">
              <div className="flex items-center justify-center mb-1">
                <Trophy className="h-4 w-4 text-yellow-600 mr-1" />
                <span className="text-xs font-medium text-muted-foreground">RECORDE</span>
              </div>
              <div className="text-xl font-bold text-yellow-700 dark:text-yellow-400">
                {longestStreak}
              </div>
              <div className="text-xs text-muted-foreground">
                {longestStreak === 1 ? 'dia' : 'dias'}
              </div>
            </div>

            <div className="text-center p-3 bg-white/50 dark:bg-black/20 rounded-lg">
              <div className="flex items-center justify-center mb-1">
                <Target className="h-4 w-4 text-blue-600 mr-1" />
                <span className="text-xs font-medium text-muted-foreground">PRÓXIMA META</span>
              </div>
              <div className="text-xl font-bold text-blue-700 dark:text-blue-400">
                {currentStreak >= 30 ? '∞' : 
                 currentStreak >= 14 ? '30' :
                 currentStreak >= 7 ? '14' :
                 currentStreak >= 3 ? '7' : '3'}
              </div>
              <div className="text-xs text-muted-foreground">
                {currentStreak >= 30 ? 'Máximo!' : 'dias'}
              </div>
            </div>
          </div>

          {/* Motivação */}
          <div className="text-center p-3 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-950 dark:to-purple-950 rounded-lg border border-blue-200 dark:border-blue-800">
            <p className="text-sm text-blue-700 dark:text-blue-300">
              {currentStreak === 0 
                ? '🌱 Comece sua jornada fazendo uma pausa hoje!'
                : currentStreak < 3
                ? '🔥 Continue assim! Cada pausa conta!'
                : currentStreak < 7
                ? '⭐ Excelente! Você está criando um hábito saudável!'
                : currentStreak < 14
                ? '🏆 Incrível! Sua consistência é inspiradora!'
                : currentStreak < 30
                ? '👑 Você é um exemplo de disciplina!'
                : '🌟 Lendário! Você dominou a arte das pausas!'
              }
            </p>
          </div>
        </div>
      </Card>

      {/* Visual da sequência - últimos 7 dias */}
      <Card className="p-4">
        <h4 className="font-medium mb-3 flex items-center">
          <Calendar className="h-4 w-4 mr-2" />
          Últimos 7 dias
        </h4>
        <div className="flex justify-between">
          {Array.from({ length: 7 }, (_, i) => {
            const date = new Date();
            date.setDate(date.getDate() - (6 - i));
            const dateStr = date.toISOString().split('T')[0];
            const dayName = date.toLocaleDateString('pt-BR', { weekday: 'short' });
            
            // Simular se houve pausa no dia (baseado na sequência atual)
            const dayIndex = 6 - i;
            const hadBreak = currentStreak > dayIndex;
            
            return (
              <div key={i} className="text-center">
                <div className="text-xs text-muted-foreground mb-1">
                  {dayName}
                </div>
                <motion.div
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-sm ${
                    hadBreak 
                      ? 'bg-green-500 text-white' 
                      : 'bg-gray-200 dark:bg-gray-700 text-muted-foreground'
                  }`}
                  whileHover={{ scale: 1.1 }}
                  transition={{ type: 'spring', stiffness: 300 }}
                >
                  {hadBreak ? '✓' : '○'}
                </motion.div>
              </div>
            );
          })}
        </div>
      </Card>
    </div>
  );
}