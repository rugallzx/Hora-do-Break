import React from 'react';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';

interface AvatarProps {
  config: {
    body: string;
    eyes: string;
    accessory: string;
    hair?: string;
  };
  energy: number;
  screenTime: number;
}

export function Avatar({ config, energy, screenTime }: AvatarProps) {
  const getEnergyColor = () => {
    if (energy > 70) return 'bg-green-500';
    if (energy > 40) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const getAvatarMood = () => {
    if (energy > 70) return 'Energético! ⚡';
    if (energy > 40) return 'Cansado 😐';
    return 'Exausto! 😴';
  };

  const getBodyColor = () => {
    switch (config.body) {
      case 'happy': return 'bg-blue-400';
      case 'tired': return 'bg-gray-400';
      case 'energetic': return 'bg-green-400';
      case 'calm': return 'bg-purple-400';
      case 'fire': return 'bg-red-400';
      case 'pink': return 'bg-pink-400';
      case 'orange': return 'bg-orange-400';
      case 'cyan': return 'bg-cyan-400';
      case 'brown': return 'bg-amber-600';
      case 'gold': return 'bg-gradient-to-br from-yellow-400 to-yellow-500';
      case 'rainbow': return 'bg-gradient-to-r from-red-400 via-yellow-400 via-green-400 via-blue-400 to-purple-400';
      default: return 'bg-blue-400';
    }
  };

  const getEyeStyle = () => {
    const baseOpacity = energy < 30 ? 'opacity-50' : 'opacity-100';
    
    switch (config.eyes) {
      case 'sleepy':
        return `${baseOpacity} transform scale-y-50`;
      case 'excited':
        return `${baseOpacity} transform scale-110`;
      case 'star':
      case 'heart':
      case 'diamond':
      case 'robot':
      case 'wink':
      case 'angry':
        return `${baseOpacity}`;
      case 'normal':
      default:
        return baseOpacity;
    }
  };

  const renderHair = () => {
    if (!config.hair || config.hair === 'none') return null;
    
    const baseClass = "absolute z-15 transition-all duration-500";
    
    switch (config.hair) {
      case 'short':
        return (
          <div className={`${baseClass} top-6 left-1/2 transform -translate-x-1/2 w-18 h-6`}>
            {/* Cabelo curto detalhado */}
            <div className="w-full h-full bg-gradient-to-b from-amber-600 to-amber-800 rounded-t-full shadow-lg"></div>
            {/* Camada de brilho */}
            <div className="absolute top-0.5 left-2 w-14 h-4 bg-gradient-to-b from-amber-500 to-amber-700 rounded-t-full opacity-70"></div>
            {/* Mechas individuais */}
            <div className="absolute top-1 left-3 w-1 h-3 bg-amber-700 rounded-t-full opacity-80"></div>
            <div className="absolute top-0.5 left-5 w-1 h-4 bg-amber-600 rounded-t-full opacity-60"></div>
            <div className="absolute top-1 right-3 w-1 h-3 bg-amber-700 rounded-t-full opacity-80"></div>
            <div className="absolute top-0.5 right-5 w-1 h-4 bg-amber-600 rounded-t-full opacity-60"></div>
            {/* Sombra natural */}
            <div className="absolute bottom-0 left-1 w-16 h-1 bg-amber-900 rounded-full opacity-40"></div>
          </div>
        );
      
      case 'long':
        return (
          <div className={`${baseClass} top-4 left-1/2 transform -translate-x-1/2 w-20 h-10`}>
            {/* Cabelo longo com volume */}
            <div className="w-full h-full bg-gradient-to-b from-amber-600 to-amber-800 rounded-t-full shadow-lg"></div>
            {/* Camada de brilho principal */}
            <div className="absolute top-1 left-2 w-16 h-8 bg-gradient-to-b from-amber-500 to-amber-700 rounded-t-full opacity-70"></div>
            {/* Mechas laterais detalhadas */}
            <div className="absolute top-7 -left-1 w-4 h-6 bg-gradient-to-b from-amber-600 to-amber-800 rounded-full transform -rotate-15 shadow-md"></div>
            <div className="absolute top-7 -right-1 w-4 h-6 bg-gradient-to-b from-amber-600 to-amber-800 rounded-full transform rotate-15 shadow-md"></div>
            {/* Textura do cabelo */}
            <div className="absolute top-2 left-4 w-0.5 h-6 bg-amber-700 rounded-full opacity-60"></div>
            <div className="absolute top-1.5 left-6 w-0.5 h-7 bg-amber-600 rounded-full opacity-50"></div>
            <div className="absolute top-2 right-4 w-0.5 h-6 bg-amber-700 rounded-full opacity-60"></div>
            <div className="absolute top-1.5 right-6 w-0.5 h-7 bg-amber-600 rounded-full opacity-50"></div>
            {/* Sombra profunda */}
            <div className="absolute bottom-0 left-2 w-16 h-1.5 bg-amber-900 rounded-full opacity-50"></div>
          </div>
        );
      
      case 'curly':
        return (
          <div className={`${baseClass} top-5 left-1/2 transform -translate-x-1/2 w-22 h-8`}>
            {/* Base do cabelo cacheado */}
            <div className="w-full h-full bg-gradient-to-b from-amber-600 to-amber-800 rounded-t-full shadow-lg"></div>
            {/* Cachos grandes */}
            <div className="absolute top-0 left-1 w-4 h-4 bg-gradient-to-br from-amber-500 to-amber-700 rounded-full shadow-md"></div>
            <div className="absolute top-0 right-1 w-4 h-4 bg-gradient-to-bl from-amber-500 to-amber-700 rounded-full shadow-md"></div>
            <div className="absolute top-1 left-1/2 transform -translate-x-1/2 w-5 h-5 bg-gradient-to-b from-amber-500 to-amber-700 rounded-full opacity-80"></div>
            {/* Cachos médios */}
            <div className="absolute top-2 left-3 w-3 h-3 bg-gradient-to-br from-amber-600 to-amber-800 rounded-full opacity-70"></div>
            <div className="absolute top-2 right-3 w-3 h-3 bg-gradient-to-bl from-amber-600 to-amber-800 rounded-full opacity-70"></div>
            {/* Cachos pequenos */}
            <div className="absolute top-3 left-5 w-2 h-2 bg-amber-700 rounded-full opacity-60"></div>
            <div className="absolute top-3 right-5 w-2 h-2 bg-amber-700 rounded-full opacity-60"></div>
            <div className="absolute top-4 left-7 w-1.5 h-1.5 bg-amber-700 rounded-full opacity-50"></div>
            <div className="absolute top-4 right-7 w-1.5 h-1.5 bg-amber-700 rounded-full opacity-50"></div>
            {/* Brilho nos cachos */}
            <div className="absolute top-0.5 left-2 w-2 h-2 bg-amber-400 rounded-full opacity-40"></div>
            <div className="absolute top-0.5 right-2 w-2 h-2 bg-amber-400 rounded-full opacity-40"></div>
          </div>
        );
      
      case 'spiky':
        return (
          <div className={`${baseClass} top-2 left-1/2 transform -translate-x-1/2 w-22 h-12`}>
            {/* Base do cabelo espetado */}
            <div className="relative w-full h-full">
              <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-18 h-4 bg-gradient-to-b from-amber-600 to-amber-800 rounded-t-full shadow-lg"></div>
              {/* Espetos detalhados com gradientes */}
              <div className="absolute bottom-3 left-2 w-2 h-6 bg-gradient-to-t from-amber-700 to-amber-500 transform -rotate-15 rounded-t-full shadow-md"></div>
              <div className="absolute bottom-2 left-4 w-2 h-8 bg-gradient-to-t from-amber-700 to-amber-500 transform rotate-8 rounded-t-full shadow-md"></div>
              <div className="absolute bottom-3 left-1/2 transform -translate-x-1/2 w-2.5 h-9 bg-gradient-to-t from-amber-700 to-amber-400 rounded-t-full shadow-lg"></div>
              <div className="absolute bottom-2 right-4 w-2 h-8 bg-gradient-to-t from-amber-700 to-amber-500 transform -rotate-8 rounded-t-full shadow-md"></div>
              <div className="absolute bottom-3 right-2 w-2 h-6 bg-gradient-to-t from-amber-700 to-amber-500 transform rotate-15 rounded-t-full shadow-md"></div>
              {/* Espetos menores */}
              <div className="absolute bottom-1 left-6 w-1.5 h-5 bg-gradient-to-t from-amber-700 to-amber-500 transform rotate-12 rounded-t-full opacity-80"></div>
              <div className="absolute bottom-1 right-6 w-1.5 h-5 bg-gradient-to-t from-amber-700 to-amber-500 transform -rotate-12 rounded-t-full opacity-80"></div>
              {/* Brilho nos espetos */}
              <div className="absolute top-1 left-1/2 transform -translate-x-1/2 w-1 h-4 bg-amber-400 rounded-t-full opacity-60"></div>
            </div>
          </div>
        );
      
      case 'mohawk':
        return (
          <div className={`${baseClass} top-1 left-1/2 transform -translate-x-1/2 w-18 h-12`}>
            {/* Moicano detalhado */}
            <div className="relative w-full h-full">
              {/* Base lateral raspada */}
              <div className="absolute bottom-0 left-0 w-full h-2 bg-gradient-to-b from-amber-700 to-amber-800 rounded-t-lg opacity-30 shadow-sm"></div>
              {/* Moicano central com volume */}
              <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-8 h-full bg-gradient-to-t from-amber-700 to-amber-500 rounded-t-full shadow-lg"></div>
              {/* Camada de brilho do moicano */}
              <div className="absolute top-1 left-1/2 transform -translate-x-1/2 w-6 h-9 bg-gradient-to-t from-amber-600 to-amber-400 rounded-t-full opacity-80"></div>
              {/* Textura do moicano */}
              <div className="absolute top-2 left-1/2 transform -translate-x-1/2 w-0.5 h-7 bg-amber-600 rounded-full opacity-70"></div>
              <div className="absolute top-3 left-1/2 transform -translate-x-1/2 translate-x-1 w-0.5 h-6 bg-amber-700 rounded-full opacity-60"></div>
              <div className="absolute top-3 left-1/2 transform -translate-x-1/2 -translate-x-1 w-0.5 h-6 bg-amber-700 rounded-full opacity-60"></div>
              {/* Sombra lateral */}
              <div className="absolute bottom-0 left-2 w-2 h-1 bg-amber-900 rounded-full opacity-50"></div>
              <div className="absolute bottom-0 right-2 w-2 h-1 bg-amber-900 rounded-full opacity-50"></div>
            </div>
          </div>
        );
      
      case 'ponytail':
        return (
          <div className={`${baseClass} top-5 left-1/2 transform -translate-x-1/2 w-20 h-10`}>
            {/* Rabo de cavalo detalhado */}
            <div className="relative w-full h-full">
              {/* Base do cabelo */}
              <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-18 h-6 bg-gradient-to-b from-amber-600 to-amber-800 rounded-t-full shadow-lg"></div>
              {/* Camada de brilho */}
              <div className="absolute top-0.5 left-1/2 transform -translate-x-1/2 w-16 h-5 bg-gradient-to-b from-amber-500 to-amber-700 rounded-t-full opacity-70"></div>
              {/* Rabo de cavalo principal */}
              <div className="absolute top-4 right-1 w-5 h-8 bg-gradient-to-b from-amber-600 to-amber-800 rounded-full transform rotate-15 shadow-md"></div>
              {/* Elástico detalhado */}
              <div className="absolute top-5 right-2.5 w-3 h-1.5 bg-amber-900 rounded-full shadow-sm"></div>
              <div className="absolute top-5.5 right-3 w-2 h-0.5 bg-amber-700 rounded-full opacity-80"></div>
              {/* Mechas do rabo */}
              <div className="absolute top-6 right-1.5 w-0.5 h-5 bg-amber-700 rounded-full opacity-70"></div>
              <div className="absolute top-6.5 right-2 w-0.5 h-4 bg-amber-600 rounded-full opacity-60"></div>
              <div className="absolute top-7 right-2.5 w-0.5 h-3 bg-amber-700 rounded-full opacity-50"></div>
              {/* Movimento natural */}
              <div className="absolute top-8 right-0.5 w-3 h-4 bg-gradient-to-b from-amber-700 to-amber-800 rounded-full transform rotate-20 opacity-80"></div>
            </div>
          </div>
        );
      
      default:
        return null;
    }
  };

  const renderEyes = () => {
    const baseClass = `flex space-x-2 ${getEyeStyle()} transition-all duration-500`;
    
    // Olhos especiais com símbolos
    if (config.eyes === 'star') {
      return (
        <div className={baseClass}>
          <div className="w-3 h-3 bg-yellow-400 relative">
            <div className="absolute inset-0 flex items-center justify-center text-xs">★</div>
          </div>
          <div className="w-3 h-3 bg-yellow-400 relative">
            <div className="absolute inset-0 flex items-center justify-center text-xs">★</div>
          </div>
        </div>
      );
    }
    
    if (config.eyes === 'heart') {
      return (
        <div className={baseClass}>
          <div className="w-3 h-3 bg-pink-400 relative">
            <div className="absolute inset-0 flex items-center justify-center text-xs">♥</div>
          </div>
          <div className="w-3 h-3 bg-pink-400 relative">
            <div className="absolute inset-0 flex items-center justify-center text-xs">♥</div>
          </div>
        </div>
      );
    }
    
    if (config.eyes === 'diamond') {
      return (
        <div className={baseClass}>
          <div className="w-3 h-3 bg-gradient-to-br from-blue-300 to-blue-500 relative transform rotate-45">
            <div className="absolute inset-0 flex items-center justify-center text-xs transform -rotate-45">♦</div>
          </div>
          <div className="w-3 h-3 bg-gradient-to-br from-blue-300 to-blue-500 relative transform rotate-45">
            <div className="absolute inset-0 flex items-center justify-center text-xs transform -rotate-45">♦</div>
          </div>
        </div>
      );
    }
    
    if (config.eyes === 'robot') {
      return (
        <div className={baseClass}>
          <div className="w-3 h-3 bg-gray-400 border border-gray-600 relative">
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-1 h-1 bg-red-500 rounded-full animate-pulse"></div>
            </div>
          </div>
          <div className="w-3 h-3 bg-gray-400 border border-gray-600 relative">
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-1 h-1 bg-red-500 rounded-full animate-pulse"></div>
            </div>
          </div>
        </div>
      );
    }
    
    if (config.eyes === 'wink') {
      return (
        <div className={baseClass}>
          <div className="w-3 h-3 bg-white rounded-full flex items-center justify-center">
            <div className="w-2 h-2 bg-black rounded-full"></div>
          </div>
          <div className="w-3 h-1 bg-black rounded-full mt-1"></div>
        </div>
      );
    }
    
    if (config.eyes === 'angry') {
      return (
        <div className={baseClass}>
          <div className="w-3 h-3 bg-red-300 relative">
            <div className="w-3 h-3 bg-gradient-to-br from-white to-gray-100 rounded-full flex items-center justify-center shadow-inner">
              <div className="w-2 h-2 bg-gradient-to-br from-gray-900 to-black rounded-full relative">
                {/* Brilho principal do olho */}
                <div className="absolute top-0.5 left-0.5 w-1 h-1 bg-white rounded-full opacity-90 shadow-sm"></div>
                {/* Reflexo secundário */}
                <div className="absolute bottom-0 right-0.5 w-0.5 h-0.5 bg-white rounded-full opacity-70"></div>
              </div>
              {/* Brilho externo do olho */}
              <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white to-transparent opacity-30 rounded-full"></div>
            </div>
            {/* Sobrancelha franzida */}
            <div className="absolute -top-1 left-0 w-3 h-1 bg-red-600 transform rotate-12 rounded-full"></div>
          </div>
          <div className="w-3 h-3 bg-red-300 relative">
            <div className="w-3 h-3 bg-gradient-to-br from-white to-gray-100 rounded-full flex items-center justify-center shadow-inner">
              <div className="w-2 h-2 bg-gradient-to-br from-gray-900 to-black rounded-full relative">
                {/* Brilho principal do olho */}
                <div className="absolute top-0.5 left-0.5 w-1 h-1 bg-white rounded-full opacity-90 shadow-sm"></div>
                {/* Reflexo secundário */}
                <div className="absolute bottom-0 right-0.5 w-0.5 h-0.5 bg-white rounded-full opacity-70"></div>
              </div>
              {/* Brilho externo do olho */}
              <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white to-transparent opacity-30 rounded-full"></div>
            </div>
            {/* Sobrancelha franzida */}
            <div className="absolute -top-1 right-0 w-3 h-1 bg-red-600 transform -rotate-12 rounded-full"></div>
          </div>
        </div>
      );
    }
    
    // Olhos normais
    return (
      <div className={baseClass}>
        <div className="w-3 h-3 bg-white rounded-full flex items-center justify-center">
          <div className="w-2 h-2 bg-black rounded-full"></div>
        </div>
        <div className="w-3 h-3 bg-white rounded-full flex items-center justify-center">
          <div className="w-2 h-2 bg-black rounded-full"></div>
        </div>
      </div>
    );
  };

  return (
    <div className="text-center space-y-4">
      {/* Avatar Visual */}
      <div className="relative mx-auto w-32 h-36 flex items-center justify-center">
        {/* Corpo */}
        <div className={`w-24 h-24 rounded-full ${getBodyColor()} relative flex items-center justify-center transition-all duration-500 z-10 mt-4`}>
          {/* Olhos - sempre renderizar, exceto quando óculos estão equipados */}
          {config.accessory !== 'glasses' && renderEyes()}

          {/* Boca baseada na energia - não renderizar se máscara está equipada */}
          {config.accessory !== 'mask' && (
            <div className="absolute bottom-6">
              {energy > 70 && (
                <div className="w-4 h-2 border-b-2 border-black rounded-full"></div>
              )}
              {energy <= 70 && energy > 40 && (
                <div className="w-3 h-1 bg-black rounded-full"></div>
              )}
              {energy <= 40 && (
                <div className="w-4 h-2 border-t-2 border-black rounded-full"></div>
              )}
            </div>
          )}
        </div>

        {/* Cabelo - renderizado atrás dos olhos mas na frente do corpo */}
        {renderHair()}

        {/* Acessórios sobrepostos com posicionamento correto */}
        
        {/* Chapéu - posicionado corretamente sobre a cabeça */}
        {config.accessory === 'hat' && (
          <div className="absolute top-4 left-1/2 transform -translate-x-1/2 w-10 h-5 bg-red-500 rounded-t-full z-30 shadow-md">
            {/* Aba do chapéu */}
            <div className="absolute -bottom-1 left-1/2 transform -translate-x-1/2 w-12 h-2 bg-red-600 rounded-full opacity-80"></div>
          </div>
        )}
        
        {/* Óculos - posicionados sobre os olhos (sobrepondo) - posição ajustada mais para baixo */}
        {config.accessory === 'glasses' && (
          <div className="absolute left-1/2 transform -translate-x-1/2 w-14 h-3 z-35" style={{ top: '68px' }}>
            {/* Armação dos óculos */}
            <div className="relative w-full h-full">
              {/* Lente esquerda */}
              <div className="absolute left-0 top-0 w-4 h-3 border-2 border-black rounded-full bg-blue-100 bg-opacity-30 shadow-sm"></div>
              {/* Lente direita */}
              <div className="absolute right-0 top-0 w-4 h-3 border-2 border-black rounded-full bg-blue-100 bg-opacity-30 shadow-sm"></div>
              {/* Ponte do nariz */}
              <div className="absolute top-1 left-1/2 transform -translate-x-1/2 w-2 h-0.5 bg-black rounded-full"></div>
              {/* Hastes */}
              <div className="absolute -left-1 top-0.5 w-1.5 h-0.5 bg-black rounded-full"></div>
              <div className="absolute -right-1 top-0.5 w-1.5 h-0.5 bg-black rounded-full"></div>
            </div>
          </div>
        )}
        
        {/* Coroa - posicionada sobre a cabeça */}
        {config.accessory === 'crown' && (
          <div className="absolute top-3 left-1/2 transform -translate-x-1/2 w-12 h-7 bg-gradient-to-b from-yellow-400 to-yellow-500 z-30 rounded-b-sm">
            {/* Base da coroa */}
            <div className="absolute bottom-0 left-0 w-full h-2 bg-yellow-600 rounded-sm"></div>
            {/* Pontas da coroa */}
            <div className="absolute top-0 left-1 w-1.5 h-4 bg-yellow-400 transform rotate-12 rounded-t-sm"></div>
            <div className="absolute top-0 left-3 w-1.5 h-5 bg-yellow-400 rounded-t-sm"></div>
            <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-1.5 h-6 bg-yellow-400 rounded-t-sm"></div>
            <div className="absolute top-0 right-3 w-1.5 h-5 bg-yellow-400 rounded-t-sm"></div>
            <div className="absolute top-0 right-1 w-1.5 h-4 bg-yellow-400 transform -rotate-12 rounded-t-sm"></div>
            {/* Joias na coroa */}
            <div className="absolute top-2 left-1/2 transform -translate-x-1/2 w-1.5 h-1.5 bg-red-500 rounded-full shadow-sm"></div>
            <div className="absolute top-3 left-3 w-1 h-1 bg-blue-500 rounded-full"></div>
            <div className="absolute top-3 right-3 w-1 h-1 bg-green-500 rounded-full"></div>
          </div>
        )}
        
        {/* Corrente - posicionada mais baixa e menor */}
        {config.accessory === 'chain' && (
          <div className="absolute left-1/2 transform -translate-x-1/2 z-15" style={{ top: '104px' }}>
            {/* Corrente dourada abaixo da boca - menor */}
            <div className="w-12 h-4 relative">
              {/* Corrente do pescoço - curva anatômica menor */}
              <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-10 h-1.5 flex items-center justify-center space-x-0.5">
                {/* Elos da corrente menores */}
                <div className="w-0.5 h-1 border border-yellow-600 rounded-full bg-gradient-to-br from-yellow-300 to-yellow-400 shadow-sm transform rotate-45"></div>
                <div className="w-0.5 h-1 border border-yellow-600 rounded-full bg-gradient-to-br from-yellow-300 to-yellow-400 shadow-sm"></div>
                <div className="w-0.5 h-1 border border-yellow-600 rounded-full bg-gradient-to-br from-yellow-300 to-yellow-400 shadow-sm transform rotate-45"></div>
                <div className="w-0.5 h-1 border border-yellow-600 rounded-full bg-gradient-to-br from-yellow-300 to-yellow-400 shadow-sm"></div>
                <div className="w-0.5 h-1 border border-yellow-600 rounded-full bg-gradient-to-br from-yellow-300 to-yellow-400 shadow-sm transform rotate-45"></div>
              </div>
              
              {/* Pingente principal com cifrão menor */}
              <div className="absolute top-1.5 left-1/2 transform -translate-x-1/2 w-2.5 h-2.5 bg-gradient-to-br from-yellow-400 via-yellow-500 to-yellow-600 rounded-full flex items-center justify-center border border-yellow-700 shadow-lg">
                <span className="text-xs font-black text-green-900 drop-shadow-sm" style={{ fontSize: '8px' }}>$</span>
              </div>
              
              {/* Efeito de brilho animado no pingente menor */}
              <div className="absolute top-1.5 left-1/2 transform -translate-x-1/2 w-2.5 h-2.5 bg-gradient-to-tr from-white via-transparent to-transparent opacity-40 rounded-full animate-pulse"></div>
            </div>
          </div>
        )}

        {/* Bandana - acessório moderno e estiloso */}
        {config.accessory === 'bandana' && (
          <div className="absolute left-1/2 transform -translate-x-1/2 w-20 h-6 z-25" style={{ top: '50px' }}>
            {/* Base da bandana */}
            <div className="w-full h-full bg-gradient-to-b from-red-600 to-red-700 rounded-lg shadow-lg"></div>
            {/* Padrão paisley clássico */}
            <div className="absolute top-1 left-2 w-2 h-2 bg-white rounded-full opacity-70"></div>
            <div className="absolute top-2 right-3 w-1.5 h-1.5 bg-white rounded-full opacity-60"></div>
            <div className="absolute top-1.5 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-white rounded-full opacity-50"></div>
            {/* Nós laterais da bandana */}
            <div className="absolute top-2 -left-1 w-3 h-2 bg-gradient-to-l from-red-600 to-red-700 rounded-full transform -rotate-12"></div>
            <div className="absolute top-2 -right-1 w-3 h-2 bg-gradient-to-r from-red-600 to-red-700 rounded-full transform rotate-12"></div>
            {/* Sombra da bandana */}
            <div className="absolute top-0.5 left-1 w-18 h-0.5 bg-red-800 rounded-full opacity-40"></div>
            {/* Detalhes do tecido */}
            <div className="absolute top-3 left-3 w-0.5 h-0.5 bg-white rounded-full opacity-30"></div>
            <div className="absolute top-3.5 right-4 w-0.5 h-0.5 bg-white rounded-full opacity-30"></div>
          </div>
        )}

        {/* Efeitos visuais baseados na energia */}
        {energy > 80 && (
          <div className="absolute inset-0 animate-pulse z-40 m-[0px]">
            <div className="w-2 h-2 bg-yellow-400 rounded-full absolute top-2 left-8 animate-bounce"></div>
            <div className="w-1 h-1 bg-yellow-400 rounded-full absolute top-4 right-6 animate-bounce delay-100"></div>
            <div className="w-1 h-1 bg-yellow-400 rounded-full absolute bottom-8 left-6 animate-bounce delay-200"></div>
          </div>
        )}
      </div>

      {/* Status */}
      <div className="space-y-2">
        <Badge variant={energy > 50 ? 'default' : 'destructive'}>
          {getAvatarMood()}
        </Badge>
        
        <div className="space-y-1">
          <div className="flex justify-between text-sm">
            <span>Energia</span>
            <span>{Math.max(0, energy)}%</span>
          </div>
          <Progress value={Math.max(0, energy)} className="h-2" />
        </div>
      </div>

      {/* Dicas baseadas no estado */}
      <div className="text-sm text-muted-foreground">
        {energy < 30 && "Seu avatar precisa de uma pausa urgente!"}
        {energy >= 30 && energy < 60 && "Que tal uma pausa em breve?"}
        {energy >= 60 && screenTime > 120 && "Você está indo bem, mas cuidado com o tempo!"}
        {energy >= 60 && screenTime <= 120 && "Excelente controle de tempo de tela!"}
      </div>
    </div>
  );
}